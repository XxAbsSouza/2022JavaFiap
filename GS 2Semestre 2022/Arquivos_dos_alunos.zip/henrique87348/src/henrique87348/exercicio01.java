package henrique87348;

import java.util.Scanner;

public class exercicio01 {

	public static void main(String[] args) {
		
		
		Scanner teclado = new Scanner(System.in);
		
		int usuarios ;
		System.out.println("quantidade de usuarios que utilizam o sistema de compartilhamento de carros");
		usuarios = teclado.nextInt();
		
		String[] nome = new String [usuarios];
		int []categoria = new int [usuarios];
		int[] tempo = new int [usuarios];
		
			for(int i = 0 ; i<usuarios ; i++) {
				System.out.println("digite o nome do usuario");
				nome[i] = teclado.next();
				System.out.println();
				
				System.out.println(" Digite qual categoria -->  1 , 2 , 3 ");
				categoria[i] =teclado.nextInt();
				
			
				if (categoria[i] !=1 && categoria[i] < 2 && categoria[i] !=3) {
					System.out.println("nao existe essa categoria");
					i--;
				}
				System.out.println("quantidade de tempo que o carro ficou em minutos");
				tempo[i] = teclado.nextInt();
			}
			
			imprimir(usuarios , tempo, nome , categoria);
			System.out.println();

	}
	public static void imprimir (int usuarios , int []tempo , String[] nome, int[]categoria) {
		int total = 0;
		double[]calcular = new  double[usuarios];
			for (int i =0 ; i < usuarios ; i++) {
				if (categoria[i] == 1 ) {
					calcular[i] = (tempo[i] * 0.50);
					
				}else if (categoria[i] == 2 ) {
					calcular[i] = (tempo[i] * 0.75);
						
					}else if (categoria[i] == 3 ) {
						calcular[i] = (tempo[i] * 1.25);
				}
				System.out.println("nome do usuario " + nome[i]);
				System.out.println();
				System.out.println("valor desse usuario é  --> " + String.format("%.2f", calcular[i]));
				total = (int) (total + calcular[i]);
			}
		
	}

}
