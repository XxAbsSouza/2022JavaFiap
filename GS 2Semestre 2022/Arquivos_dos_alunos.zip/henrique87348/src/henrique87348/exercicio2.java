package henrique87348;

import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		
		
		Scanner teclado = new Scanner(System.in);
		
	    double usuario;
		double carros = 1  ;
		double bicicletas = 1;
		int usuarios = 0;
		int[] resposta = new int[usuarios];
		System.out.println("quantidade de usuarios pesquisados ");
		usuario = teclado.nextInt();

		for (int i = 0; i < usuario; i++) {
			
			System.out.println("digite 1 para compartilhamento de carros");
			System.out.println();
			System.out.println("digite 2 implantação do aluguel da bicicletas");
			usuario = teclado.nextInt();
			System.out.println();

			if (usuarios == 1) {
				carros += 1;
				
			} else if(usuarios == 2) {
				bicicletas += 1;
			
			} 
				System.out.println();
			
		}

		usuarios = (int) ((carros / usuarios) * 100);



		System.out.println("a porcentagem é " + carros);
		System.out.println("a porcentagem é " + bicicletas);

	}

}
