import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		int QuantidadeUsuarios;
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Informe a quantidade de usuarios na pesquisa: ");
		QuantidadeUsuarios=teclado.nextInt();
		
		int[] Votos = new int [QuantidadeUsuarios];
		NumerosDeVotos(Votos);
		VerificacaoDeVotos(Votos,QuantidadeUsuarios);
		
		teclado.close();
	}

	public static void NumerosDeVotos(int[] Votos) {
		Scanner teclado = new Scanner(System.in);
		for(int i=0; i<Votos.length;i++) {
			
			System.out.println("informe a implantacao de aluguel escolhida");
			System.out.println("\n1) Para compartilhamento de carros"+ "\n2) Para aluguel de bicicletas");
			Votos[i]=teclado.nextInt();
			if(Votos[i]!=1 && Votos[i]!=2) {
				System.out.println("Opcao invalida, tente novamente !");
				break;
			}else {
				System.out.println("Opcao Valida");
				
			}
		}
		teclado.close();
		
	}
	
	public static void VerificacaoDeVotos(int[] Votos, int QuantidadeUsuarios ) {
		double bicicletas=0, carros=0;
		
		for(int i=0; i<Votos.length;i++) {
			if(Votos[i]==1) {
				carros++;
			}
			if(Votos[i]==2) {
				bicicletas++;
			}
		}
		double porcentagemcarros, porcentagembicicletas;
		porcentagemcarros=carros/(QuantidadeUsuarios*0.01);
		porcentagembicicletas=bicicletas/(QuantidadeUsuarios*0.01);
		
		System.out.println("A porcentagem de pessoas que preferem compartilhamento de carros: "+ porcentagemcarros+"%" );
		System.out.println("A porcentagem de pessoas que preferem aluguel de bicicletas: "+ porcentagembicicletas+"%" );
	}
	

}
