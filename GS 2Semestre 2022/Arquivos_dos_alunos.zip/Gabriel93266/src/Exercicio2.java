import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		
		int QuantidadeUsuarios;
		Scanner teclado= new Scanner(System.in);
		
		System.out.println("Informe a quantidade de usuarios: ");
		QuantidadeUsuarios=teclado.nextInt();

		int[] usuarios= new int[QuantidadeUsuarios];
	
		CalcularValorAluguel(usuarios,QuantidadeUsuarios);
		
		teclado.close();
	}
	
	public static void CalcularValorAluguel(int[] usuarios,int QuantidadeUsuarios) {
		Scanner teclado= new Scanner(System.in);
		int[] categoria= new int[QuantidadeUsuarios];
		double[] TempoUtilizado= new double[QuantidadeUsuarios];
		
		String[] Nome = new String[QuantidadeUsuarios];
		
		for(int i=0; i<usuarios.length;i++) {
			System.out.println("Informe seu Nome: ");
			teclado.nextLine();
			Nome[i]=teclado.nextLine();
			System.out.println("\nInforme a categoria do carro utilizado nas seguintes opcoes: "+ "\n1)Popular"+ "\n2)Confort"+ "\n3)Premium");
			categoria[i]=teclado.nextInt();
			if(categoria[i]!=1 && categoria[i]!=2 && categoria[i]!=3) {
				System.out.println("Categoria invalida, tente novamente !");
				break;
			}else {
				System.out.println("Informe o tempo de utilizicao do carro em minutos: ");
				TempoUtilizado[i]=teclado.nextDouble();
				CalcularValor(TempoUtilizado,categoria,usuarios,Nome);
			}
		}
		teclado.close();
		
	}
	
	public static void CalcularValor(double[] TempoUtilizado, int[] categoria,int[] usuarios,String[] Nome) {
		double[] Gasto= new double[usuarios.length];
		double[] aux=  new double[usuarios.length];
		
		System.out.println("\nValores gastos por usurios em reais: ");
		for(int i=0; i<usuarios.length;i++) {
			if(categoria[i]==1) {
				Gasto[i]=TempoUtilizado[i]*0.5;
				System.out.println("O usuario " + "#"+ (i+1) + " gastou: R$"+ String.format("%.2f", Gasto[i]));
				aux[i]=Gasto[i];
			}else if (categoria[i]==2) {
				Gasto[i]=TempoUtilizado[i]*0.75;
				System.out.println("O usuario " + "#"+ (i+1) + " gastou: R$"+ String.format("%.2f", Gasto[i]));
				aux[i]=Gasto[i];
			}else if(categoria[i]==3) {
				Gasto[i]=TempoUtilizado[i]*1.25;
				System.out.println("O usuario "+ "#"+ (i+1) + " gastou: R$"+ String.format("%.2f", Gasto[i]));
				aux[i]=Gasto[i];
			}
		}
		
		CalcularFinal(Gasto);
	}

	public static void CalcularFinal (double[] Gasto) {
		double aux=0;
		for(int i=0; i<Gasto.length;i++) {
			aux+=Gasto[i];
		}
		System.out.println("O Faturamento total da empresa foi de: R$"+ String.format("%.2f", aux));
	}


}
