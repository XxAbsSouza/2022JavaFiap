import java.util.Random;
import java.util.Scanner;

public class exercicio2 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int qtdUsuario;
		
		System.out.println("Digite a quantidade de usuários que utilizaram o sistema de compartilhamento de carros no último mês:");
		qtdUsuario = scan.nextInt();
		System.out.println();
		armazenarUsuario(qtdUsuario);
		
		
	}
	
	public static void armazenarUsuario(int qtdUsuario) {
		
		Scanner scan = new Scanner(System.in);
		
		String [] nome = new String [qtdUsuario];
		int [] categoria = new int [qtdUsuario];
		double [] tempo = new double [qtdUsuario];
		
		for(int i =0; i < qtdUsuario; i++) {
			System.out.println("Usuário numero "+i);
			
			System.out.println();
			
			System.out.println("Digite o seu nome: ");
			nome[i] = scan.next();
			
			System.out.println("Digite a categoria do carro utilizado: ");
			categoria[i] = scan.nextInt();
			
			System.out.println("Digite o tempo em mintos que você utilizou o carro: ");
			tempo[i] = scan.nextDouble();
			
			System.out.println();
		}
		
		return;
	}
	
}
