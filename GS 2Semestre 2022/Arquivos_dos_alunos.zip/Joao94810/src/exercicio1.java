import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int qtdUsuario, escolha;
		double bicicleta=0, carro=0;
		
		System.out.println("Insira a quantidade de usuários: ");
		qtdUsuario = scan.nextInt();
		
		System.out.println();
		
		for (int i = 1; i <=qtdUsuario; i++) {
			System.out.println("Usuário número "+i);
			System.out.println("Digite 1 se preferir a implantação de compartilhamento de carros,"
					+ " digite 2 se prefere a implantação de aluguel de bicicletas:");
			escolha = scan.nextInt();
			if(escolha == 1) {
				carro++;
			} else if(escolha == 2) {
				bicicleta++;
			} else {
				System.out.println("Número inválido");
			}
			
			System.out.println();
		}
		
		carro = 100 * carro /qtdUsuario;
		bicicleta = 100 * bicicleta /qtdUsuario;
		
		System.out.println(carro+"% dos usuários escolheram a implantação de compartilhamento de carros.");
		System.out.println();
		System.out.println(bicicleta+"% dos usuários escolheram a implantação de aluguel de bicicletas.");
		
	}
	
}
