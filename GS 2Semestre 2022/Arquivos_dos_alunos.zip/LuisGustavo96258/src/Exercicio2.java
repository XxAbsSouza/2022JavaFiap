import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int qntdusuarios;
		
		System.out.print("Quantos usuarios utilizaram o sistema?: ");
		qntdusuarios = teclado.nextInt();
		
		
		int [] usuarios = new int [qntdusuarios];
		String [] nomes = new String [qntdusuarios]; 
		dados(usuarios,nomes);
		
	
	}

	public static void dados(int [] usuarios, String [] nomes) {
		//a
		Scanner teclado = new Scanner(System.in);
		int [] carros = new int [usuarios.length];
		double [] tempo = new double [usuarios.length] ;
		for (int i = 0; i < usuarios.length; i++) {
			System.out.println("Usuario #" + (i+1));
			System.out.println();
			System.out.print("Nome: ");
			nomes[i] = teclado.nextLine();
			System.out.println();
			System.out.print("Qual o tipo de carro utilizado 1, 2 ou 3: ");
			carros[i] = teclado.nextInt();
			System.out.println();
			System.out.print("Quanto tempo utilizado(Apenas o numero em minutos)? ");
			tempo[i] = teclado.nextDouble();
			teclado.nextLine();
			
		}
		ganhos(usuarios,carros,nomes,tempo);
	}
	public static void ganhos(int [] usuarios, int [] carros, String [] nomes, double [] tempo) {
		//b
		
		Scanner teclado = new Scanner(System.in);
		double custo1,custo2,custo3, valor = 0, ganhostotais = 0;
		
		System.out.println();
		System.out.print("Qual o custo de utilização do carro 1 por minuto? ");
		custo1 = teclado.nextDouble();
		System.out.println();
		System.out.print("Qual o custo de utilização do carro 2 por minuto? ");
		custo2 = teclado.nextDouble();
		System.out.println();
		System.out.print("Qual o custo de utilização do carro 3 por minuto? ");
		custo3 = teclado.nextDouble();
		System.out.println();
		
		for (int i = 0; i < usuarios.length; i++) {
			System.out.print(nomes[i]);
			if (carros[i] == 1) {
				valor = custo1 * tempo[i];
				ganhostotais = ganhostotais + valor;
			}else if (carros[i] == 2) {
				valor = custo2 * tempo[i];
				ganhostotais = ganhostotais + valor;
			}else if (carros[i] == 3) {
				valor = custo3 * tempo[i];
				ganhostotais = ganhostotais + valor;
			}
			System.out.println(" "+"gastou ao todo: R$" + String.format("%.2f", valor));
		}
		imprimir(ganhostotais);
		
	}
	//c
	public static void imprimir(double ganhostotais) {
		System.out.println();
		System.out.print("O ganho total que a Empresa recebeu foi de : R$" + String.format("%.2f", ganhostotais));
	}
	
}
