import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int usuarios;
		double porcentagemB = 0,porcentagemC = 0;
		int [] preferencia;
		
		System.out.print("Quantos usuarios?: ");
		usuarios = teclado.nextInt();
		
		preferencia = new int [usuarios];
		//a
		for (int i = 0; i < preferencia.length; i++) {
		System.out.println();
		System.out.print("Usuario #" + (i+1) + "\n");
		System.out.println("Qual voce prefere? Compartilhamento de carro ou aluguel de bicicleta?");
		System.out.print("Para bicicletas digite 1 e para carros 2:");
		preferencia[i] = teclado.nextInt();
		
			if (preferencia[i] == 1) {
				porcentagemB++;
			}
			else if (preferencia[i] == 2) {
				porcentagemC++;
			}
			
		}
		//b
		porcentagemB = porcentagemB/usuarios * 100;  
		porcentagemC = porcentagemC/usuarios * 100;  
		System.out.println();
		System.out.println("A porcentagem de usuarios ");
		System.out.println("Que preferiram as bicicletas: " + String.format("%.2f", porcentagemB) + "%");
		System.out.println("Que preferiram os carros: " + String.format("%.2f", porcentagemC) + "%");
		
		
	
	
	}

}
