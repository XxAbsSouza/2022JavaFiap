package felipe95599;

import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Seja bem vindo ao sistema CarSharingSbroubous");
		System.out.println("As categorias dos carros são: ");
		System.out.println("1- R$0,50 por minuto" + "\n2- R$0,75 por minuto" + "\n3- R$1,25 por minuto");

		System.out.println("Digite o numero de usuarios: ");
		int users = sc.nextInt();

		String[] names = new String[users];
		int[] category = new int[users];
		int[] minutes = new int[users];

		guarda(names, category, minutes);
		gasto(names, category, minutes);
		receita();

		// +string.format("%.2f",d)

		sc.close();
	}

	static Scanner sc = new Scanner(System.in);
	static double totalLucro = 0;

	public static void guarda(String[] x, int[] y, int[] z) {

		for (int i = 0; i < x.length; i++) {
			int categoria = 0;
			System.out.println("Digite o nome do usuario " + (i + 1));
			x[i] = sc.nextLine();
			System.out.println("Digite a categoria do carro ");
			categoria = sc.nextInt();
			while (categoria > 3 || categoria <= 0) {
				System.out.println("Valor incorreto!!!\nInsira novamente:");
				categoria = sc.nextInt();
			}
			y[i] = categoria;
			System.out.println("Tempo em Minutos utilizados: ");
			z[i] = sc.nextInt();
			sc.nextLine();
			System.out.println();
		}
	}

	public static void gasto(String[] x, int[] y, int[] z) {
		for (int i = 0; i < x.length; i++) {
			System.out.println("------------------------");
			System.out.println("Usuario " + (i + 1) + ": " + x[i]);
			System.out.println("Categoria: " + y[i]);
			System.out.println("Tempo Utilizado: " + z[i] + " minutos");
			if (y[i] == 1) {
				System.out.println("Total " + ": R$" + String.format("%.2f", (z[i] * 0.5)));
				totalLucro += z[i] * 0.5;
			} else if (y[i] == 2) {
				System.out.println("Total " + ": R$" + String.format("%.2f", (z[i] * 0.75)));
				totalLucro += z[i] * 0.75;
			} else {
				System.out.println("Total " + ": R$" + String.format("%.2f", (z[i] * 1.25)));
				totalLucro += z[i] * 1.25;
			}
		}
	}

	public static void receita() {
		System.out.println("\n\n");
		System.out.println("A Receita do ultimo mes foi de: R$" + String.format("%.2f", totalLucro));
	}
}
