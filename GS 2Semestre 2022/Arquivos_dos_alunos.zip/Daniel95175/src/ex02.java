import java.util.Scanner;

public class ex02 {

	public static void main(String[] args) {

		Scanner key = new Scanner(System.in);
		int qntUsuarios;
		String nome = " ";
		int minutos = 0, modelo = 0;
		double valorTotal;
		
		System.out.print("Informe quantos usuarios compartilharam o carro nesse mes: ");
		qntUsuarios = key.nextInt();
		dados (qntUsuarios, minutos, modelo, nome);
		valorTotal = gasto (qntUsuarios, minutos, modelo, nome);
		totalEmpresa (valorTotal);
	}

	public static void dados(int qntUsuarios, int minutos, int modelo, String nome ) {
		Scanner key = new Scanner(System.in);
		for (int i = 0; i < qntUsuarios; i++) {
			System.out.println();
			System.out.print("Informe o nome do "+(i+1)+"# usuario: ");
			nome = key.next();
			System.out.print("Informe o tempo de uso que o usuario utlizou o carro em minutos: ");
			minutos = key.nextInt();
			System.out.print("Qual categoria de carro o usuario utlilizou? (As categorias sao separados por '1, 2 ou 3') ");
			modelo = key.nextInt();
		}
	}
	
	public static double gasto(int qntUsuarios, int minutos, int modelo, String nome) {
		double resultado, total = 1;
		for (int i = 0; i < qntUsuarios; i++) {
			
			if(modelo == 1) {
				resultado = minutos * 0.50;
				System.out.println(nome + "Gastou no total = " + resultado + String.format("%.2f", resultado));
				
			} else if(modelo == 2) {
				resultado = minutos * 0.75;
				System.out.println(nome + "Gastou no total = " + resultado + String.format("%.2f", resultado));
				
			} else {
				resultado = minutos * 1.25;
				System.out.println(nome + "Gastou no total = " + resultado + String.format("%.2f", resultado));
				
			}
			total += resultado;
			resultado=0;
		}
		return total;
		
	}
	public static void totalEmpresa(double valorTotal) {
		System.out.println("Este foi o total que a empresa recebeu neste mes: " + valorTotal + String.format("%.2f", valorTotal));
	}	
}
