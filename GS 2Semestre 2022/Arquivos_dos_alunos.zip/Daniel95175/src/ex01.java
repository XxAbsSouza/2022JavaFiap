import java.util.Scanner;

public class ex01 {
	public static void main(String[] args) {
		
		Scanner key = new Scanner(System.in);
		int qntUsuarios, carros = 0, bicicletas = 0;
		  
		
		System.out.print("Digite a quantidade de usuarios: ");
		qntUsuarios = key.nextInt();
		
		int [] x = new int [qntUsuarios];
		
		for (int i = 0; i <x.length; i++) {
		System.out.print("O usuario "+(i+1)+"# preferem a implementacao do compartilhamento de carros ou o aluguel de bicicletas? "
				+ "(Digite 1 para os carros e 2 para as bicicletas) ");
		x[i] = key.nextInt();
		
		if(x[i] == 1) {
			carros += 1;
		}else {
			bicicletas += 1;
		}
		
		
		}
		System.out.println("Carros: " + carros +" / "+ "Bicicletas: "+bicicletas);
		
		
		
		
		
	}

}
