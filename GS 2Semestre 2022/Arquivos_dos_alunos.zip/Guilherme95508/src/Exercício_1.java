import java.util.Scanner;

public class Exercício_1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		int usuarios;
		double carros = 0;
		double bicicletas = 0;
		
		System.out.print("Numero total de usuarios --> ");
		usuarios = teclado.nextInt();
		
		int [] totalUsuarios = new int[usuarios];
		
		for (int i = 0; i < totalUsuarios.length; i++) {
			System.out.println("Usuario #" + ( i + 1) + " digite '1' para carros ou '2' para bicicletas -->");
			int aux = teclado.nextInt();
			
			if (aux == 1) {
				carros = carros + 1;
			} else if(aux ==2) {
				bicicletas = bicicletas + 1;
			} else {
				System.out.println("Valor invalido, reinicie");
				break;
			}
		}
		
		carros = (carros * 100)/ usuarios; 
		bicicletas = (bicicletas * 100)/ usuarios;
		
		System.out.print("\nPreferem compartihamento de carros: " + carros + "%");
		System.out.println();
		System.out.print("\nPreferem aluguel de bicicletas: " + bicicletas + "%");
	}

}
