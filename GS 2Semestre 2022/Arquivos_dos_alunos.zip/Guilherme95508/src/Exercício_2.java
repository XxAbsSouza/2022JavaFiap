import java.util.Scanner;

public class Exercício_2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		int usuarios;
		double total = 0;
		
		System.out.print("total de Usuarios que utilizaram o sistemas --> ");
		usuarios = teclado.nextInt();
		
		entradaDeDados(usuarios);

		
	}
	
	public static void entradaDeDados(int usuarios) {

		
		Scanner teclado = new Scanner(System.in);
		String [] nome = new String[usuarios];
		int [] categoria = new int[usuarios];
		double [] minutos = new double[usuarios];
		
		for (int i = 0; i < nome.length; i++) {
			
			System.out.print("Nome do usuarios #"+ (i+1)+": ");
			nome[i] = teclado.nextLine();
			
			System.out.print("Categoria escolhida: ");
			categoria[i] = teclado.nextInt();
			
			System.out.print("Tempo utilizado: ");
			minutos[i] = teclado.nextDouble();
			
			teclado.nextLine();
			System.out.println();
			
			gastoUsuario(nome[i], categoria[i], minutos[i]);
			System.out.println();
		}
	}
	
	public static double gastoUsuario(String nome, int categoria, double minutos) {
		
		if (categoria == 1) {
			System.out.print("Usuario "+ nome + " gastou : R$" + String.format("%.2f", 0.50 * minutos));
			return 0.50 * minutos;
		} else if( categoria == 2) {
			System.out.print("Usuario "+ nome + " gastou : R$" + String.format("%.2f", 0.75 * minutos));
			return 0.75 * minutos;
		} else {
			System.out.print("Usuario "+ nome + " gastou : R$" + String.format("%.2f", 1.25 * minutos));
			return 1.25 * minutos;
		}	

		
	}
	
}
