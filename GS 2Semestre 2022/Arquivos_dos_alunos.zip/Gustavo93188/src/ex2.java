import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		int QtdDeUsuarios;
		double ac1 = 0, ac2 = 0;
		double pct1, pct2;
		
		System.out.println("Digite a quantidade de usuários");
		QtdDeUsuarios = teclado.nextInt();
		
		int [] x = new int [QtdDeUsuarios];
		
		for(int i = 0; i < x.length ; i++) {
			System.out.println("usuário "+ (i+1)+", Se você preferir compartilhamneto de carro digite 1, Se preferir aluguel de bicicleta digite 2");
			x[i] = teclado.nextInt();
			if(x[i] == 1) {
				ac1 += 1;
				
			}
			
			if(x[i] == 2) {
				ac2 +=1;
			}
			
		}
		System.out.println("% de pessoas que preferem carro: " + (ac1/QtdDeUsuarios) * 100 + "%");
		System.out.println("% de pessoas que preferem aluguel de bike: " + (ac2/QtdDeUsuarios)*100 + "%");
		
		
		

	}

}
