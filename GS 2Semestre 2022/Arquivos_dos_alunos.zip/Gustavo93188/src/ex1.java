import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		int numDeUsuarios;
		
		System.out.print("Digite o numero de usuários ---> ");
		numDeUsuarios = teclado.nextInt();

		String[] nomes = new String[numDeUsuarios];
		int[] ctg = new int[numDeUsuarios];
		int[] tempo = new int[numDeUsuarios];
		double total1[] = new double[numDeUsuarios];
		double total2[] = total1;
		
		entrada(ctg,nomes ,tempo);
		aluguel(ctg,nomes ,tempo, total1);
		total(total2);
		
		
	}
	
	public static void entrada(int[]ctg, String[]nomes, int[]tempo ) {
		Scanner teclado = new Scanner(System.in);
		for(int i = 0; i < ctg.length; i++) {
			System.out.print("Nome do usuário " + (i+1)+":");
			nomes[i] = teclado.nextLine();	
			System.out.println("Categoria do usuário " + (i+1)+":");
			ctg[i] = teclado.nextInt();
			System.out.println("tempo em minutos do usuário " + (i+1)+":");
			tempo[i] = teclado.nextInt();
			teclado.nextLine();
		}
		
		
	}
	
	public static double[] aluguel(int[]ctg, String[]nomes, int[]tempo, double[] total1) {
		for(int i = 0; i < ctg.length; i++) {
			double gasto;
			if(ctg[i] == 1) {
				gasto = tempo[i] *0.5;
				System.out.println(nomes[i] + ":  "+ String.format("%.2f", gasto) +" Reais");
			}
			
			if(ctg[i] == 2) {
				gasto = tempo[i]*0.75;
				System.out.println(nomes[i] + ":  "+ String.format("%.2f", gasto)+" Reais");
			}
			
			if(ctg[i] == 3) {
				gasto = tempo[i] * 1.25;
				System.out.println(nomes[i] + ":  "+ String.format("%.2f", gasto)+" Reais");
			}
			
			
		}
		
		for(int i = 0 ; i < total1.length; i++) {
			if(ctg[i] == 1) {
				total1[i] = tempo[i] *0.5;
				
			}
			
			if(ctg[i] == 2) {
				total1[i] = tempo[i]*0.75;
				
			}
			
			if(ctg[i] == 3) {
				total1[i] = tempo[i] * 1.25;
				
			}

			
			}
		return(total1);
		
	}
	
	public static void total(double[] totalGeral) {
		double aux = 0;
		for(int i = 0; i < totalGeral.length; i++) {
			aux += totalGeral[i];
		}
		System.out.print("Faturamento mensal --> "+ String.format("%.2f", aux)+" Reais");
			
			
			
			
			
		
		
		
		
		
			
		
		
	}

}
