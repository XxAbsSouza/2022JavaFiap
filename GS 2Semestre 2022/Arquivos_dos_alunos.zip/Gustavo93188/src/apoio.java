
public class apoio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static void aluguel(int[]ctg, String[]nomes, int[]tempo) {
		for(int i = 0; i < ctg.length; i++) {
			double gasto;
			if(ctg[i] == 1) {
				gasto = tempo[i] *0.5;
				System.out.println(nomes[i] + ":  "+ String.format("%.2f", gasto) +" Reais");
			}
			
			if(ctg[i] == 2) {
				gasto = tempo[i]*0.75;
				System.out.println(nomes[i] + ":  "+ String.format("%.2f", gasto)+" Reais");
			}
			
			if(ctg[i] == 3) {
				gasto = tempo[i] * 1.25;
				System.out.println(nomes[i] + ":  "+ String.format("%.2f", gasto)+" Reais");
			}
			
		}
	}

}
