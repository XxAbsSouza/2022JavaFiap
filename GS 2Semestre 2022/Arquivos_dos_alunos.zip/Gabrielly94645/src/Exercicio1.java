import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado = new Scanner(System.in);
		
		int usuarios = 0;
		int[] categocarros = new int[usuarios];
		int[] tempomin = new int[usuarios];
		String[] usuarionome = new String[usuarios];
	
		
		System.out.println("Digite a quantidade de usuarios: ");
		usuarios = teclado.nextInt();
		
	    LereArmazenar(usuarios, tempomin, categocarros, usuarionome);
	    NomeseValor(usuarios, tempomin, categocarros, usuarionome);
	    
	}
	
        public static void LereArmazenar(int usuarios, int[] tempomin, int[] categocarros2, String[]usuarionome) {
    
        	Scanner teclado = new Scanner(System.in);
        	String[] usuarionome1 = new String [usuarios];
        	int[] tempo1 = new int[usuarios];
        	int[] categocarros = new int [usuarios];
        	for(int i = 0; i < usuarios; i++) {
        		
        	System.out.println("Digite seu nome: ");
        	usuarionome1 [i] = teclado.nextLine();
        	
        	System.out.println("Digite a categoria do seu carro (1, 2 ou 3): ");
        	categocarros[i] = teclado.nextInt();
        	
        	System.out.println("Qual o tempo em minutos no qual o carro foi utilizado? ");
            tempo1 [i] = teclado.nextInt();
            teclado.nextLine();
        	}
        }
        
        public static void NomeseValor(int usuarios3, int[] tempoemmin3, int[] categocarros3, String[]usuarionome ) {
        	double valor = 0;
        	for(int i = 0; i < usuarios3; i++) {
        		int[] categocarros = new int [usuarios3];
				if (categocarros [i] == 1) {
					valor = 0.5 * tempoemmin3 [i];
					System.out.println( "Valor: "+ valor);
				}else if (categocarros[i] == 2) {
					valor = 0.75 * tempoemmin3[i];
					System.out.println("Valor: " + valor);
					System.out.println(valor);
				}else {
					valor = 1.25 * tempoemmin3[i];
					System.out.println("Valor" + valor);
				}
				

        	}
        	
        	
        }
        
        
        public static void GanhoEmpresa(int x) {
        	int lucro = 0;
        	double valor = 0;
        	lucro = (int) (valor * 30);
        	System.out.println("O ganho final é de R$: " + lucro);
        }
        
        
}
