import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int usuarios;
		double CarrosPorcent, BicicletaPorcent;
		Scanner teclado = new Scanner(System.in);
		 int aux = 0;
		System.out.println("Informe a quantidade de usuarios: ");
		usuarios = teclado.nextInt();
		
		int[] favoritodoUsuario = new int[usuarios];
		for(int i = 0; i < usuarios; i++) {
			System.out.println("Nos informe sua preferencia, para Carros digite 0 e para Bicicletas digite 1");
			favoritodoUsuario [i] = teclado.nextInt();
			if (favoritodoUsuario[i] == 0) {
				aux = aux + 1;
			}
			
			CarrosPorcent = (100 * aux / usuarios);
			System.out.println("Porcentagem por Carros: %" + CarrosPorcent);
			
			BicicletaPorcent = (100 - CarrosPorcent);
			System.out.println("Porcentagem por Bicicleta: %" + BicicletaPorcent);
		}
		
		
	}

}
 