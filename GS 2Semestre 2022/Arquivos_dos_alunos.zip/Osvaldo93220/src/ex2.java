import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner (System.in);

	int usuarios;
	System.out.println("Digite a quantidade de usuarios que usaram o sistema de carro no ultimo mes");
	usuarios = teclado.nextInt();
	
	String[] nome = new String[usuarios];
	int [] categoria = new int[usuarios];
	int [] tempo = new int[usuarios];
	
	for (int i = 0; i < usuarios; i++) {
		System.out.print("Digite o nome do usuario: ");
		nome[i]= teclado.next();
		System.out.print("Digite a categoria do carro: digitado 1, 2, 3 de acordo com a sua: ");
		categoria[i] = teclado.nextInt();
		if(categoria[i] !=1 &&categoria[i] !=2 &&categoria[i] !=3) {
			System.out.println("Essa categoria nao existe errorrrrr");
			i--;
			teclado.close();
		}
		System.out.print("Digite a quantidade de tempo em minutos que o usuario utilizou o carro: ");
		tempo[i] = teclado.nextInt();
		
	}
	imprimir(usuarios, tempo, nome, categoria);
	System.out.println();
	
	}private static void imprimir(int usuarios, int[] tempo, String[] nome, int[] categoria) {
		// TODO Auto-generated method stub
		double []calculo = new double[usuarios];
		double total=0;
		for (int i = 0; i < usuarios; i++) {
			if(categoria[i]==1) {
				calculo[i] = (tempo[i]* 0.50);
			}else if(categoria[i]==2) {
				calculo[i] = (tempo[i]* 0.75);
			}else if(categoria[i]==3) {
				calculo[i] = (tempo[i]* 1.25);
			}
			System.out.println("Nome do usuario: " +nome[i]);
			System.out.println("O valor desse usuario e de: "+String.format("%.2f", calculo[i]));
			
			System.out.println("--------------");
			total = total + calculo[i];
			
		}
		System.out.println();
		System.out.println("O total que a CarSharingSbrobous Ltda arrecadou no final do mes foi de: " +String.format("%.2f", total));
			
		
	}
	
			
		}
	


