import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		int usuarios;
		double carro=0, bicicleta=0;
		double contac, contab;
		System.out.print("Digite a quantidade de usuarios pesquisados: ");
		usuarios = teclado.nextInt();
		int [] resposta = new int [usuarios];
		
		for (int i = 0; i < usuarios; i++) {
			System.out.println("Digite 1 se o usuario preferir a implantacao do compartilhamento de carros");
			System.out.print("OU Digite 0 para implantacao do aluguel de bicicletas: ");
			resposta[i] = teclado.nextInt();
			
			if(resposta[i] == 1) {
				carro++;
			}else if (resposta[i] == 0) {
				bicicleta ++;
			}
			else {
				System.out.println("Valor incorreto");
				i--;
			}
		}
		contac = ((carro/usuarios)*100);
		contab = ((bicicleta/usuarios)*100);
		System.out.println("A porcentagem que preferre carro e de: " +contac +"%");
		System.out.println("A porcentagem que preferre bicicleta e de: " +contab +"%");
	
	teclado.close();	
	}
	

}
