 package yann93609;

import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner key =new Scanner(System.in);
		int qntUsr, car = 0, bike=0, porcem=0, porcem1=0, aux;
		
		System.out.println("Digite a quantidade de usuarios pesquisados: ");
		qntUsr=key.nextInt();

		int []opUsr=new int [qntUsr];
		
		for (int i = 0; i < opUsr.length; i++) {
			System.out.println("Informe sua opniao, para compartilhamento de dados digite 1, para aluguel de bicicletas digite 2 ");
			System.out.print("Usuario "+(i+1)+": ");
			opUsr[i]=key.nextInt();	
			if (opUsr[i]==1) {
				car++;
			}else if (opUsr[i]==2) {
				bike++;
			}else {System.out.println("Valores invalidos, reinicie a aplicacao");
			break;
			}
			}aux=car+bike;
			porcem=(100*car)/aux;
			porcem1=(100*bike)/aux;
			System.out.println();
			System.out.println("A porcentagem de usuarios que preferem o compartilhamento de carros e de: "+porcem+"%" );
			System.out.println();
			System.out.println("A porcentagem de usuarios que preferem o aluguel de bicicletas e de: "+porcem1+"%" );

	}

}
//coloquei sem acento algum por conta de no terminal não apararece o caractere