package yann93609;

import java.util.Iterator;
import java.util.Scanner;

public class ex2 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner key=new Scanner(System.in);
		int qntUsr;
		System.out.println("Informe a quantidade de usuarios que ultilizaram o sistema de compartilhamento de carros no ultimo mes: ");
		qntUsr=key.nextInt();
		String[] name=preenche2(qntUsr);
		int[] tipo=	preenche1(qntUsr);
		double[] time=preenche3(qntUsr);
		print(name, tipo, time);
		printT(time);
		
	}public static int []preenche1(int qntUsr){
		int[]tipo=new int[qntUsr];
		Scanner key=new Scanner(System.in);
		for (int i = 0; i < tipo.length; i++) {
			System.out.println("Qual o tipo de veiculo o usuario "+(i+1)+" ultilizou? (sao eles: 1, 2 ou 3)");
			tipo[i]=key.nextInt();
		}
		return tipo;
		
	}public static String[] preenche2(int qntUsr){
		String[]name=new String[qntUsr];
		Scanner key=new Scanner(System.in);
		for (int i = 0; i < name.length; i++) {
			System.out.println("Qual o nome do usuario "+(i+1)+"?");
			name[i]=key.nextLine();
		}
		return name;
	}public static double[] preenche3(int qntUsr){
		double[]time=new double[qntUsr];
		Scanner key=new Scanner(System.in);
		for (int i = 0; i < time.length; i++) {
			System.out.println("Por quanto tempo o usuario "+(i+1)+" ultilizou? (Digite em minutos)");
			time[i]=key.nextDouble();
			
		}
		return time;
	}public static double[] print(String name[], int[]tipo, double []time) {
		
		double[] gasto = new double[tipo.length];
	for (int i = 0; i < tipo.length; i++) {
		if (tipo[i]==1) {
			gasto[i]=time[i]*0.5;
		}else if (tipo[i]==2) {
			gasto[i]=time[i]*0.75;
		}else if (tipo[i]==3) {
			gasto[i]=time[i]*1.25;
			}
		System.out.println("O "+name[i]+" gastou R$ "+String.format("%.2f", gasto[i]));
		
		}
	return gasto;
	}public static void printT(double[]gasto) {
		double total = 0;
		for (int i = 0; i < gasto.length; i++) {
			total+=gasto[i];
		}
		System.out.println("o valor total referente ao ultimo mes que a empresa recebeu com o compartilhamento de carros foi de aproximadamente: "+String.format("%.2f", total)+"R$");
	}
	

}
