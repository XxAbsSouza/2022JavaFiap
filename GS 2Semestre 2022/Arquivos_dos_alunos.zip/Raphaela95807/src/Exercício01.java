import java.util.Scanner;

public class Exercício01 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int qtdUsuarios; 
		
		System.out.println("Quantidade de usuários que utilizaram o sistema: ");
		qtdUsuarios = teclado.nextInt(); 
		
		
		entradaUsuario(qtdUsuarios);
		
		
		} // fim bloco Main
	
	
	
		// Metodo que faz a entrada de dados do usuário
	public static void entradaUsuario(int qtdUsuarios) {
		Scanner teclado = new Scanner(System.in);
		String nomes [] = new String [qtdUsuarios];
		int categoria [] = new int [qtdUsuarios];
		double minutos [] = new double [qtdUsuarios];
		
		for(int i = 0; i < qtdUsuarios; i++) {
			System.out.println("Nome Usuário #" + (i + 1) + ": ");
			nomes[i] = teclado.next();
			
			
			System.out.println("Categoria do carro utilizado: ");
			categoria[i] = teclado.nextInt();
			
			System.out.println("Minutos de utilização do veiculo: ");
			minutos[i] = teclado.nextDouble();
						
		}
		
		calcularSharing(nomes, categoria, minutos);
		
		//for(int j = 0; j < qtdUsuarios; j++) {
			//System.out.print(nomes[j] + " - ");
		//}
	}

	
	
	public static void calcularSharing(String[] nomes, int[] categoria, double[] minutos){
			
		double totalGasto [] = new double [categoria.length];
		
		for(int i = 0; i < categoria.length; i++) {
			if(categoria[i] == 1) {
				totalGasto[i] = minutos[i] * 0.50;
			}
			else if(categoria[i] == 2) {
					totalGasto[i] = minutos[i] * 0.75;
				} 
			else {
					totalGasto[i] = minutos[i] * 1.25;
					}
							}
		
		calcularTotal(nomes, categoria, minutos, totalGasto);
		
		
		}// fim metodo calcularSharing
	
	
	
	public static void calcularTotal(String[] nomes, int[] categoria, double[] minutos, double[]totalGasto) {
		
		for(int total = 0; total < categoria.length; total++) {
			
		System.out.print("O gasto total do(a) " + nomes[total] + " foi de: R$ ");
		System.out.printf("%.2f", totalGasto[total]);
		System.out.println(" ");
		
		}
		
		double [] valorTotal;
		double aux = 0;
		double soma = 0;
		
		for(int v = 0; v < categoria.length; v++) {
			soma += totalGasto[v];
			}
		
		System.out.print("No total a empresa CarSharingSbrobous recebeu R$ ");
		System.out.printf("%.2f",soma);
		}



	
	
		
		
	}
	



