import java.util.Scanner;

public class Exercício02 {

	public static void main(String[] args) {
		
		
		int qtdPesquisados;
		
		Scanner teclado = new Scanner(System.in); 
		
		System.out.println("Quantidade de usuários pesquisados: ");
		qtdPesquisados = teclado.nextInt();
		
		
		int vetorVotos [] = new int [qtdPesquisados];
		
		System.out.println(" ATENCAO INSTRUCOES ABAIXO: ");
		System.out.println("Para votar na implantação de aluguel de CARROS digite 1.");
		System.out.println("Para votar na implantação de aluguel de BICICLETAS digite QUALQUER OUTRO NÚMERO. ");
		System.out.println(" ");
		
		for(int i = 0; i < qtdPesquisados; i++) {
			System.out.println("Usuario #" + (i+1) + " digite seu voto: ");
			vetorVotos[i] = teclado.nextInt();
			}
		
		int votosCarros = contabilizarVotosCarros(vetorVotos);
		int votosBikes = contabilizarVotosBikes(vetorVotos);
		calcularMedia(votosCarros, qtdPesquisados);
		
		System.out.println("Total de votos a favor da implantação de alugel de CARROS: " + votosCarros + " - Porcentagem: " + calcularMedia(votosCarros, qtdPesquisados));
		System.out.println("Total de votos a favor da implantação de alugel de BICICLETA: " + votosBikes + " - Porcentagem: " + calcularMedia(votosBikes, qtdPesquisados));
		
		
		
	}

	public static double calcularMedia(int votos, int qtdPesquisados) {
		
		double media = 0;
		
		media = (votos / qtdPesquisados) * 100;
		
		return media;
		
		
	}

	public static int contabilizarVotosBikes(int[] vetorVotos) {
		
		int totalMotos = 0;
		
		for(int i = 0; i < vetorVotos.length; i++) {
			if(vetorVotos[i] != 1) {
				totalMotos += 1;
			}
		}
		
		
		
		return totalMotos;
	
		
	}

	public static int contabilizarVotosCarros(int[] vetorVotos) {
		
		int totalCarros = 0;
		
		for(int i = 0; i < vetorVotos.length; i++) {
			if(vetorVotos[i] == 1) {
				totalCarros += 1;
			}
		}
		
		return totalCarros;
		
		
	}
	
	
	

}
