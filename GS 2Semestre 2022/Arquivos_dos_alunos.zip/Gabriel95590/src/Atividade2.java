import java.util.Scanner;

public class Atividade2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int qtdUsuario, categoria, tempo;
		int usuario = 0, minutos;
		String [] nomes = null;
		double [][] carros = null;
		double total = 0;
		
		qtdUsuario = usuarios(usuario);
		nomes = nomeUser(nomes, usuario);
		impressaoNome(nomes);
		carros = impressaoInfo(carros, usuario, nomes);
		
		}
	
	public static int usuarios(int usuarios) {
		Scanner teclado = new Scanner(System.in);
		System.out.println(" Digite usuarios de acesso do ultimo mes ");
		usuarios = teclado.nextInt();
		return usuarios;
	}
	
	public static double [][] informacoes(double [][] carros, String [] nome , int usuario){
		Scanner teclado = new Scanner(System.in);
		carros = new double[usuario][3];
		for(int i = 0; i < usuario; i++) {
			System.out.println("\n Usuario " + nome[i]);
			do {
				System.out.println(" Qual categoria voce utilizou, 1 ou 2 ou 3 ? ");
				carros [i][0] = teclado.nextDouble();
			} while (carros[i][0] < 1 || carros [i][0] > 3);
			System.out.println(" Quantos minutos utilizou? ");
			
			carros[i][1] = teclado.nextDouble();
			if (carros[i][0] == 1) {
				carros[i][2] = carros[i][1] * 0.5;
			} else if (carros[i][0] == 2) {
				carros[i][2] = carros[i][2] * 0.75;
			} else {
				carros[i][2] = carros[i][2] * 1.25;
			}
		}
		return carros;
	}
	
	public static String[] nomeUser(String[] nome, int usuario) {
		Scanner teclado = new Scanner(System.in);
		nome = new String[usuario];
		for(int i = 0; i < usuario; i++) {
			System.out.println(" Usuario " + " " + (i + 1));
			nome[i] = teclado.nextLine();
			
		}
		return nome;
	}
	
	public static void impressaoNome(String [] nome) {
		System.out.println();
		for(int i = 0; i < nome.length; i++) {
			System.out.println(nome[i]);
			System.out.println();
		}
	}
	
	public static void impressaoInfo(double [][] carros, int usuarios, String [] nome) {
		System.out.println("\n");
		for(int i = 0; i < carros.length; i++) {
			System.out.println();
		}
	}

}
