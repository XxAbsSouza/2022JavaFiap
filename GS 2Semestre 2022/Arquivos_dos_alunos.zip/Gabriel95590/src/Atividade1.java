import java.util.Scanner;

public class Atividade1 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int qtdUsuario, carros = 0, bicicletas = 0;
	    int usuario =0;
	
		
		
		System.out.println(" Digite a quantidade de Usuarios pesquisados ");
		qtdUsuario = teclado.nextInt();
		
		int[] voto = new int [qtdUsuario];
			System.out.println(" Estamos fazendo uma pesquisa e queremos saber se voce prefere implantacao do compartilhamento de carros ou de aluguel de bicicletas ");
			System.out.println(" \nPara carro digite 1 ");
			System.out.println(" \nPara aluguel de bicicletas digite 2 ");
			System.out.println();
						
			for( int user = 1; user <= qtdUsuario; user++) {
				
				System.out.println("\n Usuario # " + user + " Digite seu voto ");
					voto[usuario] = teclado.nextInt();
					if (voto[usuario] == 1 || voto[usuario] == 2) {
						if (voto[usuario] == 1) {
							carros++;
						} else {
							bicicletas++;
						}
						
					} 
					
					else {
						System.out.println(" Voto invalido ");

					}
					
			}
			
			bicicletas = (bicicletas * 100) / qtdUsuario;
			carros = (carros * 100) / qtdUsuario;
			
			System.out.println("\n Votos para alguel de bicicletas --> " + bicicletas + "%");
			System.out.println("\n Votos para o compartilhamento de carros --> " + carros + "%");
			
		}
		
		

	}


