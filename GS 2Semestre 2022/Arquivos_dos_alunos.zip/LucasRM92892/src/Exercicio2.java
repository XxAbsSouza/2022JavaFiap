import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int valor;

		System.out.print("Digite a quantidade de usuarios que utilizou o compartilhamento de carros no ultimo mes ");
		valor = teclado.nextInt();

		double[] valorTotal = Exercicio2.armazenaUsuario(valor);

		double total = 0;
		for (int i = 0; i < valorTotal.length; i++) {
			
			total = total + valorTotal[i];
			
		}
		
		System.out.println("O valor total que a empresa recebeu " + total);
		
	}

	public static double[] armazenaUsuario(int quantidadeUsuarios) {

		Scanner teclado = new Scanner(System.in);

		String[] nomeUsuarios = new String[quantidadeUsuarios];
		int[] tipo = new int[quantidadeUsuarios];
		double[] tempo = new double[quantidadeUsuarios];

		for (int i = 0; i < nomeUsuarios.length; i++) {

			System.out.println("Digite o nome do usuario# " + (i + 1));
			nomeUsuarios[i] = teclado.nextLine();

		}

		for (int i = 0; i < tipo.length; i++) {

			System.out.println("Digite o categoria do usuario# " + (i + 1)
					+ " (Lembrando que a categoria são apenas os numeros 1, 2 ou 3)");
			tipo[i] = teclado.nextInt();

		}

		for (int i = 0; i < tempo.length; i++) {

			System.out.println("Digite o tempo em minutos que do usuario# " + (i + 1) + " utilizou o carro");
			tempo[i] = teclado.nextDouble();
			

		}

		String[][][] listaUsuario = new String[nomeUsuarios.length][tipo.length][tempo.length];
		double[] valorGasto = new double[quantidadeUsuarios];

		for (int i = 0; i < listaUsuario.length; i++) {

			if (tipo[i] == 1) {
				valorGasto[i] = 0.50 * tempo[i];

			} else if (tipo[i] == 2) {

				valorGasto[i] = 0.75 * tempo[i];

			} else if (tipo[i] == 3) {

				valorGasto[i] = 1.25 * tempo[i];
			}

		}

		Exercicio2.imprime(nomeUsuarios, valorGasto);
		
		return valorGasto;
	}

	public static void imprime(String[] nomeUsuarios, double[] valorGasto) {

		

		for (int i = 0; i < nomeUsuarios.length; i++) {
				
			System.out.println("Tabela com nome e o valor gasto ");

			System.out.println(nomeUsuarios[i] + "\t" + valorGasto[i]);
		}

	}
}
