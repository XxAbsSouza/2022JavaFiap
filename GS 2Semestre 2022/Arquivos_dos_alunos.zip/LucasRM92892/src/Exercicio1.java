import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {


		Scanner teclado = new Scanner(System.in);
		
		
		
		int valor, somaDeCarro, somaDeBicicleta;
		
		System.out.print("Digite a quantidade de usuarios pesquisados ");
		valor =  teclado.nextInt();
		int [] usuario =  new int [valor];
		
		System.out.println("Muito bem, vamos começar!");
		
		somaDeCarro = 0;
		somaDeBicicleta = 0;
		for(int i = 0; i < usuario.length; i++ ) {
			
			System.out.println("Digite o numero 1 se o usuario prefere o compartilhamento de "
					+ "carros ou digite 2 se o usuario prefere a implantação de aluguel "
					+ "de bicicletas " + "USUARIO# " +  (i + 1));
			usuario[i] = teclado.nextInt();
			
			if(usuario[i] == 1) {
				
				somaDeCarro++;
				
			}else if(usuario[i] == 2) {
				
				somaDeBicicleta++;
				
				
			}else {
				
				System.out.println("Caracter errado, rode o programa novamente e tente de novo!");
				
			}
		}
		
		double porCarro, porBici;
		
		
		porCarro = (somaDeCarro * 100) / valor;
		porBici = 	(somaDeBicicleta*100)/valor;
		
		System.out.println("O valor em porcentagem de usuarios que escolheu compartilhamento de carros foi de "
				+ porCarro + "%");
		System.out.println("O valor em porcentagem de usuarios que escolheu implantação de aluguel de bicicletas foi de "
				+ porBici + "%");
		
		
		
		

	}

}
