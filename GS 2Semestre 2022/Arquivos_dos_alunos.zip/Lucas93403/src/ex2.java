import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int total;
		int implantacao;
		int local[] = new int [2];
		

		System.out.println("Digite o valor total de Usuarios");
		total = teclado.nextInt();

		String usuario[] = new String[total];

		for (int i = 0; i < total; i++) {

			System.out.println("Digite seu Nome ---> ");
			usuario[i] = teclado.next();

			System.out.println("Digite numero par Para escolher aluguel de bicleta ou impar para escolher compartilhamento de  carro ");
			implantacao = teclado.nextInt();

			if (implantacao % 2 == 0) {
				System.out.println(usuario[i] +" "+ "escolheu =  "  + "bicicleta");
				local[0] = implantacao - 1 ;
				System.out.println("\nTotal de bicicleta = " + local[0]);
			
			} else {
				System.out.println(usuario[i] + " " + " escolheu = " +  "carro");
				local[1] = implantacao - 1 ;
				System.out.println("\nTotal de Carros = " + local[1]);
				
			}

		}
	}

}
