import java.util.Scanner;
import java.util.Iterator;
import java.util.Random;

public class Ex1 {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		int total;

		System.out.println("Digite o numero total de Clientes ");
		total = teclado.nextInt();

		String usuario[] = new String[total];
		
		int categorias;

		for (int i = 0; i < total; i++) {

			System.out.println("Digite o Nome do Usuario");
			usuario[i] = teclado.next();

		}
		

		classe(total);
		tempo(total, usuario);
		lista(total, usuario);

	}

	public static void classe(int total) {

		int categoria[];
		categoria = new int[] { 1, 2, 3 };

		for (int i = 0; i < categoria.length; i++) {
			System.out.println("Categoria do Cliente" + categoria[i]);
		}

	}

	public static void tempo(int total, String usuario[]) {

		Random gerador = new Random();

		int tempo[] = new int[total];
		for (int i = 0; i < tempo.length; i++) {
			tempo[i] = gerador.nextInt(1, 60);
			for (int j = 1; j < total; j++) {
				System.out.println("Tempo Utilizado" + " " + tempo[i] + " " + "minutos" + " " + "Usuario" + " " + usuario[i]);
			}
		}

	}

	public static void lista(int total, String usuario[]) {
      
	   
		
	}
	
	public static void imprimir (int total) {
		
	}

}
