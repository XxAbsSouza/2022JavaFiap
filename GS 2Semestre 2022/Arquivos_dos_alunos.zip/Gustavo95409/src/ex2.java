import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.print("Quantidade de usuários: ");
		int qtdUsuario = keyboard.nextInt();
		int []preferencia = new int[qtdUsuario];
		int carros = 0, bicicletas = 0;
		double porcentagemCarros, porcentagemBicicletas;
		
		
		
		
		for (int i = 0; i < qtdUsuario; i++) {
			System.out.print("\nUsuário " + (i + 1));
			System.out.print("\nDigite 1 se prefere a implantação do compartilhamento de carros ou digite 2 se prefere a implantação do aluguel de bicicletas: ");
			preferencia[i] = keyboard.nextInt();
			while (preferencia[i] != 1 && preferencia[i] != 2) {
				System.out.print("Número inválido. Por favor, digite 1 se prefere a implantação do compartilhamento de carros ou digite 2 se prefere a implantação do aluguel de bicicletas: ");
				preferencia[i] = keyboard.nextInt();
				}
			if (preferencia[i] == 1) {
				carros++;
			} else {
				bicicletas++;
			}
		}
		
		porcentagemCarros = carros * 100.0 / qtdUsuario;
		porcentagemBicicletas = 100.0 - porcentagemCarros;
		
		System.out.print("\nPorcentagem de usuários que preferem o compartilhamento de carros: " + String.format("%.2f", porcentagemCarros) + "%");
		System.out.print("\nPorcentagem de usuários que preferem o compartilhamento de bicicletas: " + String.format("%.2f", porcentagemBicicletas) + "%");
		
		
		
	}

}
