import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);

		System.out.print("Quantos usuários utilizaram o sistema de de compartilhamento de carros no último mês? ");
		int qtdUsuario = keyboard.nextInt();
		passandoQuantidadeUsuario(qtdUsuario);
	}

	
//////////////////////////PRIMEIRO MÉTODO////////////////////////
	public static void passandoQuantidadeUsuario(int qtdUsuario) {
		Scanner keyboard = new Scanner(System.in);
		String[] usuario = new String[qtdUsuario];
		int[] categoria = new int[qtdUsuario];
		int[] tempo = new int[qtdUsuario];
		double[] valorAluguel = new double[qtdUsuario];
		double totalEmpresa = 0;

		for (int i = 0; i < qtdUsuario; i++) {
			System.out.print("\n\nNome de usuário: ");
			usuario[i] = keyboard.nextLine();
			System.out.print("Digite a categoria do carro utilizado (1, 2 ou 3): ");
			categoria[i] = keyboard.nextInt();
			while (categoria[i] != 1 && categoria[i] != 2 && categoria[i] != 3) {
				System.out.print(
						"Por favor, digite um número válido. Digite a categoria do carro utilizado (1, 2 ou 3): ");
				categoria[i] = keyboard.nextInt();
			}
			System.out.print("Digite o tempo em minutos em que o carro foi utilizado: ");
			tempo[i] = keyboard.nextInt();
			keyboard.nextLine();
			if (categoria[i] == 1) {
				valorAluguel[i] = 0.5 * tempo[i];
			} else if (categoria[i] == 2) {
				valorAluguel[i] = 0.75 * tempo[i];
			} else {
				valorAluguel[i] = 1.25 * tempo[i];
			}
			totalEmpresa += valorAluguel[i];
		}
		passandoElementos(usuario, valorAluguel);
		passandoTotalEmpresa(totalEmpresa);
	}
//////////////////////////PRIMEIRO MÉTODO////////////////////////

	
	
//////////////////////////SEGUNDO MÉTODO////////////////////////
	public static void passandoElementos(String[] usuario, double[] valorAluguel) {
		System.out
				.println("\n\nListagem dos nomes dos usuários com os respectios valores gastos na utilização dos carros: ");
		for (int i = 0; i < usuario.length; i++) {
			System.out.println(usuario[i] + "---> " + "R$" + String.format("%.2f", valorAluguel[i]));
		}
	}
//////////////////////////SEGUNDO MÉTODO////////////////////////

	
	
//////////////////////////TERCEIRO MÉTODO////////////////////////
	public static void passandoTotalEmpresa(double totalEmpresa) {
		System.out.print(
				"\n\nO valor total que a empresa CarSharingSbrobous Ltda recebeu no último mês com o compartilhamento dos carros foi: R$"
						+ String.format("%.2f", totalEmpresa));
	}
//////////////////////////TERCEIRO MÉTODO////////////////////////

}
