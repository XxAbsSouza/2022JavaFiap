import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		
		
		Scanner teclado = new Scanner (System.in);
		
		int qnt_usuario, opcao;
		double porcentagem_carros, porcentagem_bicicletas;
		
		System.out.print("Informe a quantidade de usuarios pesquisados: ");
		qnt_usuario = teclado.nextInt();
		
		int total_carros = 0;
		int total_bicicletas = 0;
		
		for( int i = 1; i <= qnt_usuario; i++) {
			
			System.out.println("\n\n------- Usuario "+ i + " -------");
			
			System.out.println("\nCaso prefira a implementacao do aluguel de bicicletas -> Digite '0' ");
			System.out.println("\nCaso prefira a implementacao do compartilhamento de carros-> Digite '1' ");
			opcao = teclado.nextInt();
			
			if(opcao == 0) {
				total_bicicletas += 1;
				
			}else if(opcao == 1){
				total_carros += 1;
			}else {
				System.out.print("\nApenas sao permitidas as opcoes 1 e 0. Por favor insira um numero valido. ");
			}
		
		}
		
		porcentagem_carros = ( total_carros * 100 ) / (double) qnt_usuario;
		porcentagem_bicicletas = ( total_bicicletas* 100 ) / (double) qnt_usuario;
		
		
		if(porcentagem_carros == 100) {
			System.out.println("\n\n ----> "+String.format("%.2f", porcentagem_carros)+"% dos usuarios preferem a implementacao do compartilhamento de carros");
		}else if(porcentagem_bicicletas == 100) {
			System.out.println("\n\n ----> "+String.format("%.2f", porcentagem_bicicletas)+"% dos usuarios preferem a implementacao do aluguel de bicicletas");
		}else {
			System.out.println("\n\n ----> "+String.format("%.2f", porcentagem_carros)+"% dos usuarios preferem a implementacao do compartilhamento de carros, enquanto os "+String.format("%.2f", porcentagem_bicicletas)+"% restantes preferem a implementacao do aluguel de bicicletas ");
		}

		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
