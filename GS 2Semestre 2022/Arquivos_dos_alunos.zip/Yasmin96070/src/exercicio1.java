import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		
		int qnt_usuarios;
		
		System.out.print("Informe a quantidade de usuarios: ");
		qnt_usuarios = teclado.nextInt();
		
		System.out.println("\n Para cada usuario informe seu nome, a categoria do carro utilizado e o tempo em minutos que o usuario utilizou o carro.");
		
		
		int [] categoria = new int [qnt_usuarios];
		double [] minutos = new double [qnt_usuarios];
		String [] nome = new String [qnt_usuarios];
		
		preencheDados(qnt_usuarios, categoria, minutos, nome);
		imprimeDados(qnt_usuarios, categoria, minutos, nome);
		
		
	}
	
	

	
	public static void preencheDados(int usuarios, int[] categoria, double [] minutos, String [] nome) {
		
		Scanner teclado = new Scanner (System.in);
		
		for(int i = 0; i < usuarios; i++) {
			
			
			System.out.println("\n\n------- USUARIO "+ (i+1) +" -------");
			
		
			System.out.print("\n----> Nome : ");
			nome [i] = teclado.nextLine();
			
			
			System.out.print("\n----> Categoria do carro (1, 2 ou 3) : ");
			categoria [i] = teclado.nextInt();
			
			
			System.out.print("\n----> Tempo de utilizacao (em minutos) : ");
			minutos [i] = teclado.nextDouble();
			teclado.nextLine();
			
		}
		
		
	}
	
	
	
	public static void imprimeDados (int usuarios, int[] categoria, double [] minutos, String [] nome) {
		
		double total = 0;
		
		for(int i =0; i < usuarios; i++) {
			
			
			if(categoria[i] == 1) {
				total = minutos [i] * 0.50;
			} else if (categoria[i] == 2) {
				total = minutos [i] * 0.75;
			} else {
				total = minutos [i] * 1.25;
			}
			
			
			System.out.println("\n\n------- USUARIO "+ (i+1) +" -------");
			System.out.print("\nNome = " + nome [i] + "\nValor total = "+String.format("%.2f", total));
			
		}
		
		
		
	}
	
	
	
	
	
	
	

}




























