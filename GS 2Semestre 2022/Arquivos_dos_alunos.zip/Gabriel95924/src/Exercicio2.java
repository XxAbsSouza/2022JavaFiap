import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int usuarios;
		String[] nome;
		double[] categoria;
		double[] tempo;
		
		System.out.print("Informe a quantidade de usuários que utilizaram o compartilhamento de"
				+ " carros no ultimo mês: ");
		usuarios = teclado.nextInt();
		
		System.out.println();

		pegarValores(usuarios);
	}
	
	public static void pegarValores(int usuarios) {
		Scanner teclado = new Scanner(System.in);
		String[] nome = new String[usuarios];
		double[] categoria = new double[usuarios];
		double[] tempo = new double[usuarios + 1];
		
		for(int i = 0; i < usuarios; i++) {
			System.out.println("Usuário " + (i + 1));
			System.out.print("Insira o nome: ");
			nome[i] = teclado.nextLine();
			do {
				System.out.println("Insira a categoria do carro utilizado");
				System.out.print("1, 2 ou 3: ");
				categoria[i] = teclado.nextDouble();
				if (categoria[i] > 3 || categoria[i] <= 0) {
					System.out.println("Opção inválida");
				}
			} while(categoria[i] > 3 || categoria[i] <= 0);
			
			System.out.print("Insira em minutos o tempo que o carro foi utilizado: ");
			tempo[i] = teclado.nextDouble();
			System.out.println();
			teclado.nextLine();		
		}
		
		imprimirCalcular(nome, categoria, tempo, usuarios);
		imprimirValor(tempo);
	}
	
	public static void imprimirCalcular(String[] nome, double[] categoria, double[] tempo, int usuarios){
		for(int i = 0; i < usuarios; i++) {
			System.out.println("Usuário " + (i + 1));
			System.out.println(nome[i]);
			if (categoria[i] == 1) {
				tempo[i] *= 0.5; 
			}else if(categoria[i] == 2) {
				tempo[i] *= 0.75;
			}else {
				tempo[i] *= 1.25;
			}			
			System.out.println("Valor gasto com a utilização: " + tempo[i]);
			System.out.println();
		}
	}
	
	public static void imprimirValor(double[] tempo) {
		double soma = 0;
		for(int i = 0; i < tempo.length; i++) {
		soma += tempo[i];
		}
		System.out.println("A CarSharingSbrobous recebeu no último mês um valor total de: R$" + String.format("%.2f", soma));
	} 
}
