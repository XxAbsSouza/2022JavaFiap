import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int usuarios;
		double carros = 0, bicicletas = 0;
		int numeros;
		
		System.out.print("Insira a quantidade de usuários: ");
		usuarios = teclado.nextInt();
		
		System.out.println();
		
		System.out.println("Referente a implatação");
		
		for(int i = 0; i < usuarios; i++) {
			do {				
				System.out.println("Usuário " + (i + 1) );
				System.out.println("Digite 1 para Compartilhamento de carros");
				System.out.println("Digite 2 para aluguel de bicicletas");
				System.out.print("Informe: ");
				numeros = teclado.nextInt();
				if (numeros == 1) {
					carros += 1;
				} else if(numeros == 2) {
					bicicletas += 1;
				}else {
					System.out.println("Comando inválido");
				}
				System.out.println();
			}while(numeros > 2 || numeros <= 0);
		}
		
		carros = (carros/usuarios) * 100;
		bicicletas = (bicicletas/usuarios) * 100;

		System.out.println(String.format("%.2f", carros) + "% dos usuários prefererem a implantação"
				+ " do compartilhamento de carros");
		
		System.out.println(String.format("%.2f", bicicletas) + "% dos usuários preferem a implantação do "
				+ "aluguel de bicicletas");
	}

}
