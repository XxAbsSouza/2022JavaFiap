import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

		System.out.println("Insira a quantidade de usuários pesquisados: ");
		int qtdeUsuarios = scanner.nextInt();

		int[] respostas = new int[qtdeUsuarios];
		int carro = 0;
		int bicicleta = 0;

		for (int i = 0; i < qtdeUsuarios; i++) {

			do {
				System.out.println("Escolha sua preferência, digite 1 para bicicleta ou 2 para carro ");
				respostas[i] = scanner.nextInt();

				if (respostas[i] != 1 && respostas[i] != 2) {
					System.out.println("Dígito inválido, digite 1 para bicicleta ou 2 para carro: ");
				}
			} while (respostas[i] != 1 && respostas[i] != 2);

		}
		
		for(int i = 0; i < qtdeUsuarios; i++) {
			if(respostas[i] == 1) {
				bicicleta++;
			}
			
			if(respostas[i] == 2) {
				carro++;
			}
		}
		
		double porcentagem = carro * 100.0;
		porcentagem = porcentagem/qtdeUsuarios;
		
		
		System.out.println("A porcentagem de preferência de carros é: " + porcentagem);
		
		System.out.println("A porcentagem de preferência de bicicletas é: " + (100.0-porcentagem));
		
	}

}
