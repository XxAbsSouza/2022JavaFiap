import java.text.Format;
import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		
		String[] nomes = perguntaNomes();
		
		int[][] categorias = armazenaCategoria(nomes);
		
		double gastoTotal = imprimeCategoria(categorias, nomes);
		
		imprimeValorTotal(gastoTotal);
	}

	public static String[] perguntaNomes() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Insira a quantidade de usuários que utilizaram o sistema no último mês: ");
		int qtdeUsuarios = scanner.nextInt();

		String[] nomes = new String[qtdeUsuarios];

		for (int i = 0; i < qtdeUsuarios; i++) {
			System.out.println("Digite o nome do " + (i + 1) + "º usuário");
			nomes[i] = scanner.next();
		}

		return nomes;

	}

	public static int[][] armazenaCategoria(String[] nomes) {
		Scanner scanner = new Scanner(System.in);

		int[][] categorias = new int[2][nomes.length];

		for (int i = 0; i < nomes.length; i++) {

			do {
				System.out.println(nomes[i] + " digite sua categoria (1) (2) (3):");
				categorias[0][i] = scanner.nextInt();

				if (categorias[0][i] != 1 && categorias[0][i] != 2 && categorias[0][i] != 3) {
					System.out.println("Dígito inválido, digite sua categoria (1) (2) (3): ");
				}
			} while (categorias[0][i] != 1 && categorias[0][i] != 2 && categorias[0][i] != 3);

			System.out.println(nomes[i] + " digite o tempo em minutos que usou o carro:");
			categorias[1][i] = scanner.nextInt();
		}

		return categorias;
	}

	public static double imprimeCategoria(int[][] categorias, String[] nomes) {
		double gasto = 0;
		double gastoTotal = 0;
		for (int i = 0; i < nomes.length; i++) {
			if (categorias[0][i] == 1) {
				gasto = categorias[1][i] * 0.50;
			}
			if (categorias[0][i] == 2) {
				gasto = categorias[1][i] * 0.75;
			}
			if (categorias[0][i] == 3) {
				gasto = categorias[1][i] * 1.25;
			}
			
			gastoTotal += gasto;
			
			System.out.println("O usuário " + nomes[i] + " gastou " + String.format("%.2f", gasto));
		}

		return gastoTotal;
	}
	
	public static void imprimeValorTotal(double valorTotal) {
		System.out.println("O valor total que a empresa recebeu no ultimo mês foi: " + String.format("%.2f", valorTotal));
	}

}
