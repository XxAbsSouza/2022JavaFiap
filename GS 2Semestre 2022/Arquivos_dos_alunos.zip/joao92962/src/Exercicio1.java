import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Sistema de compartilhamento de carros - CarSharingSbrobous Ltda");
		
		System.out.println("Por favor, digite o número de usuários "
				+ "que utilizaram o sistema no último mês:");
		int numUsuarios = scanner.nextInt();
		scanner.nextLine();
		
		String[] nomesUsuarios = new String[numUsuarios];
		int[] categorias = new int[numUsuarios];
		double[] tempos = new double[numUsuarios];
		
		coletarInformacoes(nomesUsuarios, categorias, tempos, scanner);
		double[] precos = calcularPreco(categorias, tempos);
		
		imprimirListagem(calcularPreco(categorias, tempos), nomesUsuarios);
		imprimirLucroMensal(precos);
		
		scanner.close();
	}
	
	public static void coletarInformacoes(String[] nomes, int[] categorias, double[] tempo, Scanner sc) {
		for(int i=0; i<nomes.length; i++) {
			System.out.println("Digite o nome do " + (i+1) + "º usuário: ");
			nomes[i] = sc.nextLine();
			
			System.out.println("Digite a categoria do carro do" + (i+1) + "º usuário: ");
			categorias[i] = sc.nextInt();
			
			System.out.println("Digite o tempo de uso do carro do " + (i+1) + "º usuário");
			tempo[i] = sc.nextDouble();
			sc.nextLine();
		}
		
	}
	
	public static double[] calcularPreco(int[] categoria, double[] tempo) {
		double[] precos = new double[tempo.length];
		for(int i=0; i<precos.length; i++) {
			switch (categoria[i]) {
				case 1: {
					precos[i] = tempo[i] * 0.50;
					break;
				}
				case 2: {
					precos[i] = tempo[i] * 0.75;
					break;
				}
				default: {
					precos[i] = tempo[i] * 1.25;
				}
			
			}
		}
		return precos;
	}
	
	public static void imprimirListagem(double preco[], String[] nomes) {
		System.out.println("Listagem de usuários");
		for(int i=0; i<nomes.length; i++) {
			System.out.println((i+1) + " - " + "Nome: "+ nomes[i] + ", valor consumido: " + String.format("%.2f", preco[i]));
		}
		
	}
	
	public static void imprimirLucroMensal(double[] precos) {
		double aux = 0;
		for(double p : precos)  {
			aux += p;
		}
		System.out.println("Lucro do ultimo mês da empresa: " + aux);
	}
	
	

}
