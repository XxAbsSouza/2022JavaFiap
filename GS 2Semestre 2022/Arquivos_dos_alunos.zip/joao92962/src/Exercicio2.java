import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Total de pessoas pesquisadas: ");
		int numPesquisas = sc.nextInt();
		resultadosFinalPesquisa(respostaPesquisa(numPesquisas, sc));
		
		

	}
	
	public static int[] respostaPesquisa(int numPesquisas, Scanner sc) {
		int[] pesquisas = new int[numPesquisas];
		
		for(int i=0; i<pesquisas.length; i++) {
			System.out.println("Qual foi a resposta do pesquisado número " + (i+1)+ "?");
			System.out.println("[1] - para implantação de compartilhamento de carros \n"
					+ "[2] - para implantação de aluguel de bicicletas");
			System.out.print("Digite: ");
			pesquisas[i] = sc.nextInt();
			System.out.println();
			
		}
		return pesquisas;
	}
	
	public static void resultadosFinalPesquisa(int[] pesquisas) {
		double totalCarros =0;
		double totalBicicletas = 0;
		for(int i : pesquisas) {
			if(i == 1) {
				totalCarros++;
			} else {
				totalBicicletas++;
			}
		}
		totalCarros = totalCarros * 100.0 / pesquisas.length;
		totalBicicletas = totalBicicletas * 100.0 / pesquisas.length;
		System.out.println("\nResultados finais da pesquisa");
		System.out.println("Porcentagem de pessoas que votaram em: ");
		System.out.println("Implementação do compartilhamento de carros -> " + String.format("%.2f", totalCarros) + "%");
		System.out.println("Implementação do de aluguel de bicicletas -> " + String.format("%.2f", totalBicicletas) + "%");
		
	}

}
