import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		double bike=0, carro=0, total;
		int usuarios;
		
		System.out.print("Quantos usuarios pesquisados--> ");
		usuarios = input.nextInt();
		
		System.out.println("\nAgora digite a preferencia de implantacao\npara cada usuario.");
		System.out.println("\nDigite 1 para--> Bicicletas \nDigite 2 para --> Carros\n");
		for (int i = 0; i < usuarios; i++) {
			int aux=0;
			System.out.print("Usuario "+(i+1)+"\nPreferencia: ");
			aux=input.nextInt();
			if(aux==1||aux==2) {
				if(aux==1){
					bike++;
				}else {
					carro++;
				}
			}else {
				i--;
				System.out.println("Essa opção não existe.");
			}
		}
		total = carro+bike;
		carro = (carro/total)*100;
		bike= (bike/total)*100;
		System.out.println("\n_____Porcentagens_____");
		System.out.println("Bicicletas\t" + bike+"%");
		System.out.println("Carros\t\t" + carro+"%");
	}

}
