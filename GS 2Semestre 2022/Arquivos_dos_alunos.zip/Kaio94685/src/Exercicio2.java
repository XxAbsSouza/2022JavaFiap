import java.util.Scanner;

public class Exercicio2 {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		int usuarios = 0;
		String[] nomes=null;
		double[][] infoCarro=null;
		
		usuarios = qntdUsuario(usuarios,input);
		
		nomes = pegarNome(nomes, usuarios,input);
		
		infoCarro = pegarInfo(infoCarro,usuarios,nomes,input);
		
		imprimirInfoCarros(infoCarro, usuarios,nomes);

		imprimirTotal(infoCarro, usuarios);
	}
	

	
	
	
	
	
	public static void imprimirTotal(double[][] infoCarro,int usuarios) {
		double total=0;
		for (int i = 0; i < usuarios; i++) {
			total+= infoCarro[i][2];
		}
		System.out.println("Total arrecadado por CarSharingSbrobous\n************R$"+String.format("%.2f", total)+"************");
	}
	public static double[][] pegarInfo(double[][] infoCarro, int usuarios, String[] nomes,Scanner input) {
		infoCarro = new double[usuarios][3];
		for (int i = 0; i < usuarios; i++) {
			System.out.println("\nUsuario "+nomes[i]);
			do {
				System.out.print("Qual categoria?\n 1, 2 ou 3 ---> ");
				infoCarro[i][0] = input.nextDouble();
			}while(infoCarro[i][0]<1.0||infoCarro[i][0]>3);
			System.out.print("Quantos minutos rodados? --->");
			infoCarro[i][1] = input.nextDouble();
			if(infoCarro[i][0]==1) {
				infoCarro[i][2]=infoCarro[i][1]*0.5;
			}else if(infoCarro[i][0]==2) {
				infoCarro[i][2]=infoCarro[i][1]*0.75;
			}else {
				infoCarro[i][2]=infoCarro[i][1]*1.25;
			}
		}
		return infoCarro;
	}
	public static int qntdUsuario(int usuarios, Scanner input) {
		System.out.print("Qnt Usuarios----> ");
		usuarios = input.nextInt();
		return usuarios;
	}
	public static String[] pegarNome(String[] nome,int usuarios,Scanner input) {
		nome = new String[usuarios];
		input.nextLine();
		for (int i = 0; i < usuarios; i++) {
			System.out.print("Nome do "+(i+1)+" usuario: ");
			nome[i] = input.nextLine();
		}
		return nome;
	}
	public static void imprimirInfoCarros(double[][] infoCarro,int usuarios,String[] nomes) {
		System.out.println("\n");
		for (int i = 0; i < infoCarro.length; i++) {
			System.out.println(nomes[i]);
			System.out.println("Categoria: \t\t"+infoCarro[i][0]);
			System.out.println("Tempo(em minutos): \t"+infoCarro[i][1]+"min");
			System.out.println("Valor: \t\t\tR$"+ String.format("%.2f", infoCarro[i][2]));			
			System.out.println();
		}	
			
	}
}
