import java.util.Scanner;

public class ex_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		int [] x = new int [10];
		int aaa;	
		System.out.println("Aramazem de dados");
		ArmazenarDados(x);
	}

	public static void ArmazenarDados(int [] x ) {
		
		Scanner cate = new Scanner(System.in);
		int categoria = 0 , qtdPessoas,categoria_dois = 0 , categoria_tres = 0, categoria_um = 0, minutos;
		String nome;
		System.out.println("Quantas pessoas utilizaram o sistema no ultimo mes ? ");
		qtdPessoas = cate.nextInt();
		for (int i =0 ; i < qtdPessoas ; i++) {
			System.out.println("Escreva seu nome");
			nome = cate.next();
			
			System.out.println("Digite qual a sua categoria, escolha 1, 2 ou 3 ");
			categoria = cate.nextInt();
			
			System.out.println("Digite quantos minutos utilizou o carro ");
			minutos = cate.nextInt();
			
			
			
			
			if (categoria == 1) {
				categoria_um ++;
			}
			if (categoria ==2) {
				categoria_dois ++;
			}
			if ( categoria == 3) {
				categoria_tres ++;
			}
			
		}
			System.out.println("Esse é o tanto de pessoas que escolheram a categoria 1 : " + categoria_um);
			System.out.println("Esse é o tanto de pessoas que escolheram a categoria 2 : " + categoria_dois);
			System.out.println("Esse é o tanto de pessoas que escolheram a categoria 3 : " + categoria_tres);
				
		
	}
	
	
	
}
