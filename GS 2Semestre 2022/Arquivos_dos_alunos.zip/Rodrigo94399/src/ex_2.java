import java.util.Scanner;

public class ex_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int UsuariosPesquisados, AluguelCarros = 0, AluguelBicicletas = 0; 
		
		System.out.println("Informe a quantidade de usuarios pesquisados");
		UsuariosPesquisados = teclado.nextInt();
		
		
		for (int i =0; i < UsuariosPesquisados; i++) {
			
			System.out.println(" Olá usuário, você prefere a implantação de carros ?, Caso a resposta seja sim, Digite 1, Caso seja não, digite 2  " );
			AluguelCarros= teclado.nextInt();
			if (AluguelCarros == 1) {
				AluguelCarros ++;	
			} else {
				AluguelBicicletas ++;
			}
		}	
			System.out.println("O numero em porcentagem que prefere bicicletas é : " + AluguelBicicletas*100/UsuariosPesquisados + "%");
			System.out.println( "E");
			System.out.println ( (UsuariosPesquisados - AluguelBicicletas)*(100) / UsuariosPesquisados  + "%"+ " De pessoas preferem carros ");
			
		}
		
	}
