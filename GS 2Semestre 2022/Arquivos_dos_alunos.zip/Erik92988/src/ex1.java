import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int quantidadeUser;
		double quantidadeCarro=0.0,quantidadeBike=0.0,porcentagemCarro,porcentagemBike;
		
		
		System.out.println("Quantidade de usuários pesquisados?");
		quantidadeUser = scan.nextInt();
		int resposta []= new int [quantidadeUser];
		for(int i=0;i<quantidadeUser;i++) {
			System.out.println("usuário "+(i+1));
			System.out.println("Se preferir a implantção do compartilhamento de carros digite 0 e se preferir implantação de aluguel de bicicletas digite 1 ");
			resposta[i]= scan.nextInt();
			if(resposta[i]==0) {
				quantidadeCarro= 1+quantidadeCarro;
			}
			if(resposta[i]==1) {
				quantidadeBike = 1+quantidadeBike;
			}
			if(resposta[i]!=0&&resposta[i]!=1) {
				System.out.println("Resposta incorreta, responda dnv");
				i=i-1;
			}
		}
		porcentagemCarro=(quantidadeCarro/quantidadeUser)*100;
		System.out.println("Porcentagem de usuários que preferem a implantção do compartilhamento de carros "+porcentagemCarro);
		porcentagemBike= (quantidadeBike/quantidadeUser)*100;
		System.out.println("Porcentagem de usuários que preferem implantação de aluguel de bicicletas "+porcentagemBike);
		

	}

}
