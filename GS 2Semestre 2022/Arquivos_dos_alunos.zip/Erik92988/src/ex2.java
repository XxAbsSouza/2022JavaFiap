import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {


		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int quantidadeCarro;
		String name[];
		double[]valor;
		
		
		System.out.println("Qual a quantidade de usuários que utilizaram o sistema de compartilhamento de carro no ultimo mes?");
		quantidadeCarro= scan.nextInt();
		
		name = colhetaDadosName(quantidadeCarro);
		valor = colhetaDadosNumeros(quantidadeCarro,name);
		imprimir( valor, name, quantidadeCarro);
		imprimirTotal(valor);

	}
	public static void imprimirTotal(double valor[]) {
		double total=0;
		for(int i=0;i<valor.length;i++) {
			total= valor[i]+total;
		}
		System.out.println("O valor total que a empresa CarSharingSbrobusLtdda recebeu no ultimo mes foi ==> "+total);
	}
    public static String[] colhetaDadosName(int quantidadeCarro) {

    	Scanner scan = new Scanner(System.in);
    	String name []= new String [quantidadeCarro];
    	for(int i=0;i<quantidadeCarro;i++) {
    		 
    		System.out.println("Escreva seu nome:");
    		
    		 name[i] = scan.nextLine();
    	}
    	return name;
    }
    public static double[] colhetaDadosNumeros(int quantidadeCarro,String name[]){
    	double categoria,tempo;
    	Scanner scan = new Scanner(System.in);
    	double[]valor = new double[quantidadeCarro];
    	for(int i=0;i<quantidadeCarro;i++) {
    		
    		System.out.println(name[i]);
    		System.out.println("qual a categoria do seu carro? 1,2 ou 3?");
    		categoria = scan.nextDouble();
    		System.out.println("qual foi o tempo em minutos que foi utilizado?");
    		tempo= scan.nextDouble();
    		if(categoria==1) {
    			categoria =0.50;
    		}else if(categoria==2) {
    			categoria =0.75;
    		}else if(categoria==3) {
    			categoria=1.25;
    		}
    		valor[i]= categoria*tempo;
    		
    	}
    	return valor;
    }
    public static void imprimir(double[]valor,String name[],int quantidadeCarro) {
    	for(int i=0; i <quantidadeCarro;i++) {
    		System.out.println(name[i]+" "+valor[i]);
    	}
    	
    }
}
