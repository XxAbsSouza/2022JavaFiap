import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int quantUser;
		int[] categoria, tempo;
		double[] totalUser;
		String[] nomes;
		
		do {
			System.out.println("Digite a quantidade de usuários: ");
			quantUser = sc.nextInt();
		}while(quantUser <0);
		
		categoria = new int[quantUser];
		tempo = new int[quantUser];
		nomes = new String[quantUser];
		totalUser = new double[quantUser];
		
		for(int i =0; i< quantUser; i++) {
			nomes[i] = nome();
			categoria[i] = categoria();
			tempo[i] = tempo();
		}
		
		totalUser = imprimeECalculaTotal(nomes, categoria, tempo);
		imprimeTotal(totalUser);
		
	}
	
	public static int tempo( ) {
		int t;
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o tempo de uso em minutos: ");
		t = sc.nextInt();
		return t;
	}

	public static int categoria( ) {
		int c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite a categoria do seu carro:");
		c = sc.nextInt();
		return c;
	}
	public static String nome( ) {
		String n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite o seu nome : ");
		n = sc.nextLine();
		return n;
	}
	
	public static double[] imprimeECalculaTotal(String[] n, int[] c, int[] t) {
		double[] total = new double[c.length];
		
		for(int j=0; j<c.length; j++) {
			total[j] = 0;
			System.out.println("Usuario: " + n[j]);
			if(c[j] == 1) {
				total[j] = t[j]* 0.50;
			}
			else {
				if(c[j] == 2) {
					total[j] = t[j] * 0.75;
				}
				else {
					total[j] = t[j] * 1.25;
				}
			}
			System.out.println("Total do Usuario: " + total[j]);
		}
		return total;
	}
	public static void imprimeTotal(double[] total) {
		double t =0;
		for(int k = 0; k< total.length; k++) {
			t += total[k];
		}
		if(t % 1 == 0) {
			System.out.println("O total da empresa : " + t +"0");
		}
		else {
			if(t % 0.5 ==0) {
				System.out.println("O total da empresa :" + t +"0");
			}
			else {
				System.out.println("O total da empresa : " + t );
			}
		}
	}
	
}
