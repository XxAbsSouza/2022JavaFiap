import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int quantUser;
		double bike=0, carro=0, totalbike =0, totalcarro =0;
		int[] escolha;
		do {
			
			System.out.println("Digite a quantidade de usuarios");
			quantUser = sc.nextInt();
		}while(quantUser<0);
		
		escolha = new int[quantUser];
		for(int i =0; i<quantUser; i++) {
			System.out.println("Digite 1 para compartilhamento de carro ou 2 para aluguel de bicicleta: ");
			escolha[i] = sc.nextInt();
			if(escolha[i]== 1) {
				carro++;
			}
			else {
				bike++;
			}
		}
		totalbike = (bike* 100)/escolha.length;
		totalcarro = (carro* 100)/escolha.length;
		System.out.println();
		System.out.println("Total de escolhas para compartilhamento de carro: " + totalcarro + "%");
		System.out.println("Total de escolhas para aluguel de bike: " + totalbike + "%");
		
	}

}
