import java.util.Scanner;

public class Exercicio_02 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int qtdUsuarios, preferencia, um = 0, dois = 0;
		double porcentagem1, porcentagem2;
		
		System.out.print("Informe a quantidade de usuários: ");
		qtdUsuarios = teclado.nextInt();
		
		for(int i = 0; i < qtdUsuarios; i++) {
			System.out.println();
			System.out.println("Usuário #" + (i+1));
			System.out.print("Digite 1, e somente 1, se o uruário prefere a implementação do compartilhamento de carro, \nOU 2, e somente 2, se o usuário prefere o aluguel de bicicletas: ");
			preferencia = teclado.nextInt();
			
			if(preferencia == 1) {
				um = um + 1;
			} else if(preferencia == 2) {
				dois = dois + 1;
			} else {
				System.out.println();
				System.out.print("O valor digitado é inválido, renicie o programa");
			}
		}
		System.out.println();
		porcentagem1 =  (100 * um) / qtdUsuarios;
		porcentagem2 =  (100 * dois) / qtdUsuarios;
		System.out.println("A quantidade de usuários que preferem carro é: " + porcentagem1 + "%"
					+ ", e a que prefere aluguel de bicicleta é: " + porcentagem2 + "%");

	}

}
