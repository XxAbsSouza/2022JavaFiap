import java.util.Scanner;

public class Exercicio_01 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int qtdUsuarios;
		
		System.out.print("Informe a quantidade de usuários que o utilizaram o sistema: ");
		qtdUsuarios = teclado.nextInt();
		
		infoUsuarios(qtdUsuarios);
		
		
	}
	
	public static void infoUsuarios(int x) {
		Scanner teclado = new Scanner(System.in);
		String[] nome = new String[x];
		int categoria;
		double tempo;
		double[] gasto = new double[x];
		double receita = 0;
		
		for(int i = 0; i<x; i++) {
			System.out.println();
			System.out.print("Usuário #" + (i+1));
			System.out.println();
			System.out.print("Digite o nome do usuário: ");
			nome[i] = teclado.nextLine();
			System.out.print("Informe a categoria do carro (1,2 ou 3): ");
			categoria = teclado.nextInt();
			System.out.print("Informe o tempo, em minutos, que o usuário utilizou o carro: ");
			tempo = teclado.nextDouble();
			if(categoria == 1) {
				gasto[i] = 0.5 * tempo;
			}
			else if(categoria == 2) {
				gasto[i] = 0.75 * tempo;
			}
			else {
				gasto[i] = 1.25 * tempo;
			}
			System.out.println();
			teclado.nextLine();	
		}
		for(int i = 0; i < x; i++) {
			System.out.print("Usuário: " + nome[i] + ", gastou no total: " + String.format("%.2f", gasto[i]));
			System.out.println();
			receita = receita + gasto[i];
		}
		System.out.println();
		System.out.print("A empresa recebeu: " + String.format("%.2f", receita));
		
		
	}

}
