import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		int quantUsuarios;
		String[] nomes;
		int[] categorias;
		int[] minutos;
		double somaGasto;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.print("Quantos usuários utilizaram o sistema de compartilhamento de carros no último mês? ");
		quantUsuarios = teclado.nextInt();
		
		nomes = pegarNome(quantUsuarios);
		
		categorias = pegarCategoria(quantUsuarios);
		
		minutos = pegarMinutos(quantUsuarios);
		
		somaGasto = imprimirListagem(nomes, categorias, minutos);
		
		imprimirTotal(somaGasto);
		
	}
	
	public static String[] pegarNome(int quantUsuarios) {
		Scanner teclado = new Scanner(System.in);
		String[] nomes = new String[quantUsuarios];
		for (int i = 0; i < nomes.length; i++) {
			System.out.println("Nome usuário " + (i+1) + " -----> ");
			nomes[i] = teclado.nextLine();
		}
		
		return(nomes);
	}
	
	public static int[] pegarCategoria(int quantUsuarios) {
		Scanner teclado = new Scanner(System.in);
		int[] categorias = new int[quantUsuarios];
		for (int i = 0; i < categorias.length; i++) {
			System.out.println("Categoria do usuário(de 1 a 3) " + (i+1) + " ---->");
			categorias[i] = teclado.nextInt();
			while(categorias[i] > 3 || categorias[i] < 1) {
				System.out.println("Insira uma categoria válida!");
				System.out.println("Categoria do usuário(de 1 a 3) " + (i+1) + " ---->");
				categorias[i] = teclado.nextInt();
			}
		}
		return(categorias);
	}
	
	public static int[] pegarMinutos(int quantUsuarios) {
		Scanner teclado = new Scanner(System.in);
		int[] minutos = new int[quantUsuarios];
		for (int i = 0; i < minutos.length; i++) {
			System.out.println("Tempo que o usuário " + (i+1) + " utilizou o carro em minutos ---->");
			minutos[i] = teclado.nextInt();
		}
		return(minutos);
	}
	
	public static double imprimirListagem(String[] nomes, int[] categorias, int[] minutos) {
		double gasto, somaGasto = 0;
		
		for (int i = 0; i < nomes.length; i++) {
			System.out.println("Usuário " + nomes[i] + " ------------- ");
			if(categorias[i] == 1) {
				gasto = 0.50 * minutos[i];
				System.out.println("Seu gasto foi de ---->  R$" + String.format("%.2f", gasto));
				System.out.println();
			} else if(categorias[i] == 2) {
				gasto = 0.75 * minutos[i];
				System.out.println("Seu gasto foi de ---->  R$" + String.format("%.2f", gasto));
				System.out.println();
			} else {
				gasto = 1.25 * minutos[i];
				System.out.println("Seu gasto foi de ---->  R$" + String.format("%.2f", gasto));
				System.out.println();
			}
			somaGasto += gasto;
		}
		return(somaGasto);
	}
	
	public static void imprimirTotal(double somaGasto) {
		System.out.println();
		System.out.println("Foi faturado um total de ----> R$" + String.format("%.2f", somaGasto));
	}
	

}
