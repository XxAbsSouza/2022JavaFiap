import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int quantUsuarios;
		int[] preferencia;
		
		System.out.println("Quantos usuários pesquisados? ");
		quantUsuarios = teclado.nextInt();
		
		preferencia = pegarPreferencia(quantUsuarios);
		
		imprimirPorcentagem(preferencia, quantUsuarios);

	}
	
	public static int[] pegarPreferencia(int quantUsuarios) {
		Scanner teclado = new Scanner(System.in);
		int[] preferencias = new int[quantUsuarios];
		for (int i = 0; i < preferencias.length; i++) {
			System.out.println("Qual a preferência do usuário " + (i+1) + "? Digite 1 para bicicleta ou 2 para carro");
			preferencias[i] = teclado.nextInt();
			while(preferencias[i] < 1 || preferencias[i] > 2) {
				System.out.println("Insira uma preferencia válida");
				System.out.println("Qual sua preferência? Digite 1 para bicicleta ou 2 para carro");
				preferencias[i] = teclado.nextInt();
			}
		}
		return(preferencias);
	}
	
	public static void imprimirPorcentagem(int[] preferencias, int quantUsuarios) {
		double prefBike = 0, prefCar = 0;
		for (int i = 0; i < preferencias.length; i++) {
			if(preferencias[i] == 1) {
				prefBike++;
			} else {
				prefCar++;
			}
		}
		
		prefBike = prefBike * 100 / quantUsuarios;
		prefCar = prefCar * 100 / quantUsuarios;
		
		System.out.println("Preferem bicicletas ----> " + String.format("%.2f", prefBike) + "%");
		System.out.println("Preferem carros ----> " + String.format("%.2f", prefCar) + "%");
		
	}

}
