import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int qtdUsuarios;
		System.out.print("Quantos usuarios foram pesquisados -- > ");
		qtdUsuarios = teclado.nextInt();
		
		int[] votos = new int[qtdUsuarios];
		double votosCarro = 0;
		double votosBike = 0;
		double porcentagemcarro;
		double porcentagembike;
		int aux = votos.length;
		
		
		System.out.println("Digite 0 para alugar carros e 1 para alugar bicicletas");
		System.out.println();
		
		for (int i = 0; i < votos.length; i++) {
			System.out.print((i+1) + "º voto --> ");
			votos[i] = teclado.nextInt();
			System.out.println();
		}
		
		for (int i = 0; i < votos.length; i++) {
			if (votos[i] == 1) {
				votosBike = votosBike + 1;
			}else{
				votosCarro = votosCarro + 1;
			}
		}
		
		
		porcentagembike = votosBike / qtdUsuarios;
		
		porcentagemcarro = votosCarro /qtdUsuarios;
		
		System.out.print("A porcentagem de compartilhamentos de bicicleta --> " + (porcentagembike * 100) + " %");
		System.out.println();
		System.out.print("A porcentagem de compartilhamentos de carro --> " + (porcentagemcarro * 100) + " %");
		
	}

}
