import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int qtdUsuarios;
		System.out.print("Digite a quantidade de Usuarios que utilizaram o sistema--> ");
		qtdUsuarios = teclado.nextInt();
		System.out.println();
		
		String[] nomeUsuario = new String[qtdUsuarios];
		double[] categoria = new double[qtdUsuarios];
		double[] tempo = new double[qtdUsuarios];
		double valorGasto = 0;
		double gasto1 = 0;
		double gasto2 = 0;
		double gasto3 = 0;
		double total = 0;
		
		
		inserirDados(qtdUsuarios,nomeUsuario , categoria , tempo);
		listagem(qtdUsuarios,nomeUsuario , categoria , tempo, valorGasto, gasto1 ,gasto2 ,gasto3, total);
	}
	
	public static void inserirDados(int qtdUsuarios , String[] nomeUsurio, double[] categoria, double[] tempo) {
		Scanner teclado = new Scanner(System.in);
		
		
		
		for (int i = 0; i < qtdUsuarios; i++) {
			teclado.nextLine();
			System.out.print((i + 1) + " ºUSUARIO." + "\n");
			System.out.print("Nome --> ");
			nomeUsurio[i] = teclado.nextLine();
			
			System.out.print("Categoria (1 , 2 , 3) --> ");
			categoria[i] = teclado.nextDouble();
			
			System.out.print("Tempo de utilizacao (mim) --> ");
			tempo[i] = teclado.nextDouble();
			System.out.println();
		}
	}
	
	public static void listagem(int qtdUsuarios , String[] nomeUsurio, double[] categoria, double[] tempo, double valorGasto, double gasto1, double gasto2, double gasto3 , double total) {
	
		for (int i = 0; i < categoria.length; i++) {
			if(categoria[i] == 1) {
				valorGasto = tempo[i] * 0.50;
				System.out.print("# " + nomeUsurio[i] + " gastou --> R$ " + String.format("%.2f", valorGasto) + "\n");
				gasto1 += valorGasto;
			}else if (categoria[i] == 2) {
				valorGasto = tempo[i] * 0.75;
				System.out.print("# " + nomeUsurio[i] + " gastou --> R$ " + String.format("%.2f", valorGasto) + "\n");
				gasto2 += valorGasto;
			}else if(categoria[i] == 3) {
				valorGasto = tempo[i] * 1.75;
				System.out.print("# " + nomeUsurio[i] + " gastou --> R$ " + String.format("%.2f", valorGasto) + "\n");
				gasto3 += valorGasto;
			}	
		}
		
		total = gasto1 + gasto2 + gasto3;
		System.out.print("O lucro total da empresa foi --> R$ " + String.format("%.2f", total));
		System.out.println();
		
	}
	
	
}
