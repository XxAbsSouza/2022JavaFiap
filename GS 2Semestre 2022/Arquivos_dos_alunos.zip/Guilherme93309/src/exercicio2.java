import java.util.Scanner;

public class exercicio2 {
	
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int usuario, bike = 0, carro = 0, aux = 0, cont = 1, porc1, porc2; 
		
		System.out.print("Digite a quantidade de usuarios que participaram da pesquisa: ");
		usuario = teclado.nextInt();
		System.out.println();
		
		for(int i = 0; i < usuario; i++) {
			
			System.out.println("ususario "  + cont);
			System.out.print("Qual voce prefere, Digite (1) para aluguel de bike e (2) para compartilhamento de carro: ");
			aux = teclado.nextInt();
			System.out.println();
			
			if(aux == 1) {
				
				bike = bike + 1;
				
			} if(aux == 2) {
				
				carro = carro + 1;
				
			} 
			
			cont++;
			
		}
		
				// porcentagem
		
		
		porc1 = bike * 100 / usuario;
		porc2 = carro * 100 / usuario;
		
	
		
		System.out.println(+ porc1 + "% dos usuarios preferem o aluguel de bicicletas");
		System.out.println();
		System.out.println(+ porc2 + "% dos usuarios preferem o compartilhamento de carros");
		
		
	}

}
