import java.util.Scanner;

public class exercicio1 {
	
	public static void main(String[] args) {
		
		int usuario, categoria = 0, tempo = 0;
		
		String nome;
		
		Scanner teclado = new Scanner(System.in);
		
		System.out.print("Digite quantos usuarios utilizaram o sistema de "
				+ "compartilhamento de carros no ultimo mes --> ");
		
		usuario = teclado.nextInt();
		
		System.out.println();
		
		transporte (usuario, categoria, tempo);
	
	}
		public static void transporte (int usuario, int categoria, int tempo) {
			
			Scanner teclado = new Scanner(System.in);
			String nome;
			int aux = 1;
			
			for(int i = 0; i < usuario; i++) {
				
				System.out.println();
				System.out.println("dados do usuario " + " " + aux);
				System.out.print("Digite seu primeiro nome: ");
				nome = teclado.next();
				System.out.print("Digite a categoria do carro utilizado: ");
				categoria =  teclado.nextInt();
				System.out.print("Digite o tempo que ficou com o carro em minutos: ");
				tempo =  teclado.nextInt();
				aux++;
					
			}
			
		}    
}
