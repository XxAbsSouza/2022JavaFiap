import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
	
		Scanner teclado = new Scanner(System.in);
		
		int qusuarios;
		int carro = 1;
		int bicicleta = 0;
		int veiculos, porcentagem;
		
		double porcentagemC, procentagemB;
		
		
		System.out.println("Informe a quantidade de usuarios ");
		qusuarios = teclado.nextInt();
		
		
		System.out.println("Informe a sua preferencia, digite 1 para carro ou 0 para bicicleta ");
		veiculos = teclado.nextInt();
		
		
		
		if (carro >= 1 && bicicleta == 0) {
			
			System.out.println(" Prefere implantacao de carro" );
			
			
		}else { 
			
			System.out.println("Prefere implantacao bicicleta " );
			
			

		
			
		}
		
		
		Math.pow(carro, bicicleta);
	
	
		
	  System.out.println("Porcentagem carro" + carro);
	  porcentagemC = teclado.nextInt();
	  
	  System.out.println("Porcentagem bicicleta" + bicicleta);
	  int porcentagemB = teclado.nextInt();

	  
   
	  
	
	  
	  
	  
		
	}
		
		
		
		
	
		
		

	}


