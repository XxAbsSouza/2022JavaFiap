import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		int qusuarios, tempo, usuarios;
		int pquantidade;
		
		System.out.println("Informe a quantidade de usuarios que utilizam o sistema mensalmente ");
		
		int quantidade = teclado.nextInt();
		
		
		System.out.println("Informe o seu nome a categoria de seu carro com 1, 2 e 3 e o tempo que ultilizou ");
		pquantidade = teclado.nextInt();
	
 

	}



public static int pquantidade ( int qusuarios) {
	
	for (int i = 0; i < i; i++) {
		
		 
	
		
		
	}
	
	System.out.println("Informe o seu nome a categoria de seu carro com 1, 2 e 3 e o tempo que ultilizou ");
	
	
	
	
	
	retun pquantidade;
	
	
	
	
	}
	
	
	
	
	
		 
		
		
	}
	


	

