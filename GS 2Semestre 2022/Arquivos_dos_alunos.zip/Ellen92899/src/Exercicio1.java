import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int quant, pesquisa, carros = 0, bicicletas = 0, tC, tB;
		
		System.out.print("Digite a quantidade de usuários pesquisados: ");
		quant = teclado.nextInt();
		
		int[] usuario = new int[quant];
		
		for(int i = 0; i < usuario.length; i++) {
			System.out.println("Usuário " + (i + 1) + ": ");
			System.out.println("Prefere: 1-Compartilhamento de carros ou 2-Aluguel de Bicicletas? (Digite 1 para carros ou 2 para bicicletas)");
			pesquisa = teclado.nextInt();
			if(pesquisa == 1) {
				carros++;
			} else if(pesquisa == 2) {
				bicicletas++;
			} else {
				System.out.println("Digite 1 ou 2.");
			}
		}
		
		tC = (carros * 100) / quant; 
		tB = (carros * 100) / quant;
		
		System.out.print("Carros: " + tC + "%");
 		System.out.print("\nBicicletas: " + tB + "%");
	}

}
