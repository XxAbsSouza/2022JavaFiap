import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int quant, c = 0, t = 0;
		String n;
		double total = 0;
		
		System.out.println("Digite a quantidade de usuários: ");
		quant = teclado.nextInt();
		
		String[] nomes = new String[quant];
		int[] categoria = new int[quant];
		int[] tempo = new int[quant];
		double[] valor = new double[quant];
	
	    for(int i = 0; i < quant; i++) {
	    	// nomes[i] = pegarNome(n); // não consegui pegar o nome :(
	    	System.out.println("Usuário " + (i + 1));
	    	categoria[i] = pegarCategoria(c);
	    	tempo[i] = pegarTempo(t);
	    	
	    	if (categoria[i] == 1) {
	    		valor[i] = tempo[i] * 0.50;
	    	} else if (categoria[i] == 2) {
	    		valor[i] = tempo[i] * 0.75;
	    	} else if (categoria[i] == 3) {
	    		valor[i] = tempo[i] * 1.25;
	    	}
	    	
	    }
	    for(int i = 0; i < quant; i++) {
	    	imprimirValores(valor[i], quant, i);
	    	
	    }
	    for(int i = 0; i < quant; i++) {
	    	total += valor[i];
	    }
	    
	    valorTotal(total);
	   
	}
	public static int pegarCategoria(int c) {
		Scanner teclado = new Scanner(System.in);  
		System.out.println("Digite a categoria (Número 1, 2 ou 3): ");
		 c = teclado.nextInt();
		 return c;
	}
	public static String pegarNome(String n) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Digite o nome: ");
		n = teclado.nextLine();
		return n;
		
	}
	public static int pegarTempo(int t) {
		Scanner teclado = new Scanner(System.in);  
		System.out.println("Digite o tempo (em minutos): ");
		 t = teclado.nextInt();
		 return t;
}
	public static void imprimirValores(double valor, int quant, int i) {
		
			System.out.println("Usuário " + (i+1) + ": ");
			System.out.println("R$" + String.format("%.2f", valor));
		
	}
	public static void valorTotal(double total) {
		System.out.println("Total: " + String.format("%.2f", total));
	}
}