import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		boolean x;
		int qtd;
		int bike = 0;
		int car = 0;
		
		System.out.print("Quantos usuários serão pesquisados?");
		qtd = sc.nextInt();
		System.out.println();
		
		System.out.println("Implantação do compartilhamento de carros ou "
				+ "de aluguel de bicicletas?" );
		System.out.println();
		
		for(int i = 1; i<=qtd; i++) {
			x = true;
			
			while(x) {
				System.out.println("Usuário " + i + ": ");
				System.out.print("Digite 1 para carros ou 2 para bicicletas.");
				int choice = sc.nextInt();
			
				if((choice != 1) && (choice != 2)) {
					System.out.println("Escolha uma das opções informadas.");
					System.out.println();
				} else {
					if(choice == 1) {
						car++;
					} else {
						bike++;
					}
					
					x = false;
				}
			
			}
		
		}
		
		car = (car*100)/qtd;
		bike = (bike*100)/qtd;
		
		System.out.println();
		System.out.println("Porcentagem aproximada da preferência dos usuários: ");
		System.out.println("Carros: " + car + "%");
		System.out.println("Bicicletas: " + bike + "%");
		
	}

}
