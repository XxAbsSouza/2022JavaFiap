import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int qtd;
		double total;
		
		System.out.print("Quantos usuários usaram o compartilhamento de "
				+ "carros no último mês?");
		qtd = sc.nextInt();
		
		String [] usuarios = new String[qtd];
		int [] tipoCarro = new int[qtd];
		double [] minutos = new double[qtd];
		
		System.out.println();
		
		usuarios = calcular1(qtd);
		System.out.println();
		tipoCarro = calcular2(qtd);
		System.out.println();
		minutos = calcular3(qtd);
		System.out.println();
		imprimir1(usuarios, tipoCarro, minutos);
		imprimir2(usuarios, tipoCarro, minutos);

		
		
		
	}
	
	public static String[] calcular1(int qtd) {
		
	
		Scanner sc = new Scanner(System.in);
		
		String [] usuarios = new String[qtd];
		

		
		for(int i=0; i<qtd; i++) {
			System.out.print("Qual o nome do usuário " + (i+1) + "?");
			usuarios[i] = sc.nextLine();
		}
		
		return usuarios;
		
	}
	
	public static int[] calcular2(int qtd) {
		
		
		Scanner sc = new Scanner(System.in);
		
		int [] tipoCarro = new int[qtd];
		
		
		
		for(int i=0; i<qtd; i++) {			
			System.out.print("Qual o tipo de carro do usuário " + (i+1) + "?");
			tipoCarro[i] = sc.nextInt();
		}
		
		
		return tipoCarro;
		
	}
	
	public static double[] calcular3(int qtd) {
		
		
		Scanner sc = new Scanner(System.in);

		double [] minutos = new double[qtd];
		
		
		
		for(int i=0; i<qtd; i++) {
			System.out.print("Quantos minutos usados pelo usuário " + (i+1) + "?");
			minutos[i] = sc.nextDouble();
			sc.nextLine();
		}
		
		
		return minutos;
		
	}

	public static void imprimir1(String [] usuarios, int [] tipoCarro, double[] minutos) {
		
		double [] valor = new double[usuarios.length];
		
		for(int i=0; i<tipoCarro.length; i++) {
			if(tipoCarro[i] == 1) {
				valor[i] = minutos[i] * 0.5;
			} else {
				if(tipoCarro[i] == 2) {
					valor[i] = minutos[i] * 0.75;
				} else {
					valor[i] = minutos[i] * 1.25;
				}
			}
		}
		
		for(int i=0; i<usuarios.length; i++) {
			System.out.print(usuarios[i] + ": R$" + String.format("%.2f", valor[i]));
			System.out.println();
		}
		
		
	}
	
	public static void imprimir2(String [] usuarios, int [] tipoCarro, double[] minutos) {
		
		double [] valor = new double[usuarios.length];
		double total = 0;
		for(int i=0; i<tipoCarro.length; i++) {
			if(tipoCarro[i] == 1) {
				valor[i] = minutos[i] * 0.5;
			} else {
				if(tipoCarro[i] == 2) {
					valor[i] = minutos[i] * 0.75;
				} else {
					valor[i] = minutos[i] * 1.25;
				}
			}
			
			total += valor[i];
		}
		
		System.out.println("Total arrecadado: R$" + String.format("%.2f", total));
		
	}
}
