import java.lang.reflect.Method;
import java.util.Scanner;

public class GS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		
		double c, b;
		string[]usuario = new string[10];
		System.out.println("O usuário prefere implementar o compartilhamento de carros ou a implantação de aluguel de bicicletas?");
		
		if(c>b) {
			System.out.println("Você selecionou implementar o compartilhamento de carro");
		} else {
			System.out.println("Você selecionou implementar o compartilhamento de moto");
		}
		
		string[] usuario2 = new string[usuario.length + 1];
		System.arraycopy(usuario, 0, usuario2, 0, usuario.length);
		usuario2[usuario.length] = teclado;
		System.out.println("nome do usuário: ");
		
		System.out.println(Math.pow(c, b));
	}

}
