import java.lang.reflect.Method;
import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
		int[] x;
		int[] categoria_array = new int[4];
		int[] mês_array = new int[13];
		x = new int[13];
		 y [string] = usuario;
		String.format("Quantidade de usuários do ultimo mês ->" + x);
		for (int i  : mês_array) {
			
			
		}
		
		Method (int[4] categoria_array = new int[4]); 
			numbers [1] = 1;
			numbers [2] = 2;
			numbers [3] = 3;
			double valor;

			if(y == 1) {
				System.out.println("Categoria 1 ");
			} if( y == 2) {
				System.out.println("Categoria 2");
				
			} else {
				System.out.println("Categoria 3");
			}
			
			
			Method (String.format(y, valor));{
				
				 
			
			
		}
		
		
		
	

		
		
		
		
	}

}
