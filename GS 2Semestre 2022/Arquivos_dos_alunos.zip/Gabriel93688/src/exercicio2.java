import java.util.Scanner;

public class exercicio2 {
	static Scanner teclado = new Scanner(System.in);
	public static void main(String[] args) {
		int quantidadeUsuarios;
		
		System.out.println("Digite a quantidade de usuarios que utilizaram o sistema de compartilhamento no ultimo mes. ");
		quantidadeUsuarios = teclado.nextInt();
		System.out.println();
		
		String [] nomesUsuarios = pegarNomesUsuarios(quantidadeUsuarios);
		int [] tipoDeImplantacao = calcularTipoDeImplantacao(quantidadeUsuarios, nomesUsuarios);
		int [] minutosUtilizados = pegarMinutosUtilizados(quantidadeUsuarios, nomesUsuarios);
		double [] valoresGastos = calcularValoresGastos(quantidadeUsuarios, tipoDeImplantacao, minutosUtilizados);
		
		imprimirListagem(quantidadeUsuarios, nomesUsuarios, valoresGastos);
		calcularFaturamentoTotal(quantidadeUsuarios, valoresGastos);
	}
	
	public static String [] pegarNomesUsuarios (int quantidadeUsuarios) {
		String [] nomesUsuarios = new String [quantidadeUsuarios];
		teclado.nextLine();
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			System.out.println("Digite o nome do usuario. #" + (i+1));
			nomesUsuarios[i] = teclado.next();
			System.out.println();
		}
		return nomesUsuarios;
	}
	
	public static int [] calcularTipoDeImplantacao (int quantidadeUsuarios, String [] nomesUsuarios) {
		int [] tipoDeImplantacao = new int [quantidadeUsuarios];
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			System.out.println("Digite a categoria do carro utilizado. Usuario: " + nomesUsuarios[i]);
			System.out.println("(Entre 1, 2 e 3).");
			tipoDeImplantacao[i] = teclado.nextInt();
			System.out.println();
			while(tipoDeImplantacao[i] < 1 || tipoDeImplantacao[i] > 3) {
				System.out.println("Valor invalido. Digite novamente a categoria do carro utilizado com um dos valores abaixo. Usuario: " + nomesUsuarios[i]);
				System.out.println("(Entre 1, 2 e 3).");
				tipoDeImplantacao[i] = teclado.nextInt();
				System.out.println();
			}
		}
		return tipoDeImplantacao;
	}
	
	public static int [] pegarMinutosUtilizados (int quantidadeUsuarios, String[] nomesUsuarios) {
		int [] minutosUtilizados = new int [quantidadeUsuarios];
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			System.out.println("Digite a quantidade de tempo em minutos usadas com o carro. Usuario: " + nomesUsuarios[i]);
			minutosUtilizados[i] = teclado.nextInt();
			System.out.println();
		}
		return minutosUtilizados;
	}
	
	public static double [] calcularValoresGastos (int quantidadeUsuarios, int [] tipoDeImplantacao, int [] minutosUtilizados) {
		double [] valoresGastos = new double[quantidadeUsuarios];
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			if (tipoDeImplantacao[i] == 1) {
				valoresGastos[i] = 0.5 * minutosUtilizados[i];
			} else if (tipoDeImplantacao[i] == 2) {
				valoresGastos[i] = 0.75 * minutosUtilizados[i];
			} else {
				valoresGastos[i] = 1.25 * minutosUtilizados[i];
			}
		}
		return valoresGastos;
	}
	
	public static void imprimirListagem (int quantidadeUsuarios, String [] nomesUsuarios, double[] valoresGastos) {
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			System.out.println("Usuario: " + nomesUsuarios[i]);
			System.out.println("Valor gasto: R$" + String.format("%.2f", valoresGastos[i]));
			System.out.println();
		}
	}
	
	public static void calcularFaturamentoTotal (int quantidadeUsuarios, double [] valoresGastos) {
		double faturamentoTotal = 0;
		for (int i = 0; i < quantidadeUsuarios ; i++) {
			faturamentoTotal += valoresGastos[i];
		}
		System.out.println("Faturamento total da empresa: " + String.format("%.2f", faturamentoTotal));
	}

}
