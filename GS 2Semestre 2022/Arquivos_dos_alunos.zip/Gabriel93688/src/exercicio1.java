import java.util.Scanner;

public class exercicio1 {

	static Scanner teclado = new Scanner(System.in);
	public static void main(String[] args) {
		int quantidadeUsuarios;
		
		System.out.println("Digite a quantidade de usuarios pesquisados. ");
		quantidadeUsuarios = teclado.nextInt();
		System.out.println();
		
		int [] implantacao = escolherImplantacao(quantidadeUsuarios);
		double [] quantidadeCarrosBicicletas = calcularPorcentagem(quantidadeUsuarios, implantacao);
		
		quantidadeCarrosBicicletas[0] = quantidadeCarrosBicicletas[0] * 100 / quantidadeUsuarios;
		quantidadeCarrosBicicletas[1] = quantidadeCarrosBicicletas[1] * 100 / quantidadeUsuarios;
		
		imprimir(quantidadeCarrosBicicletas);
	}
	
	public static int [] escolherImplantacao (int quantidadeUsuarios) {
		int [] implantacao = new int [quantidadeUsuarios];
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			System.out.println("Digite a implantacao escolhida. Usuario #" + (i+1));
			System.out.println("(1 para compartilhamento de carros e 2 para aluguel de bicicletas).");
			implantacao[i] = teclado.nextInt();
			System.out.println();
			while (implantacao[i] < 1 || implantacao[i] > 2) {
				System.out.println("Numero Invalido, Digite novamente a implantacao escolhida por um dos valores abaixo. Usuario #" + i+1);
				System.out.println();
				System.out.println("(1 para compartilhamento de carros e 2 para aluguel de bicicletas).");
				implantacao[i] = teclado.nextInt();
				System.out.println();
			}
		}
		return implantacao;
	}
	
	public static double [] calcularPorcentagem (int quantidadeUsuarios, int [] implantacao) {
		double [] quantidadeCarrosBicicletas = new double [2];
		for (int i = 0 ; i < quantidadeUsuarios ; i++) {
			if (implantacao[i] == 1) {
				quantidadeCarrosBicicletas[0]++;
			} else {
				quantidadeCarrosBicicletas[1]++;
			}
		}
		return quantidadeCarrosBicicletas;
	}
	
	public static void imprimir (double [] quantidadeCarrosBicicletas) {
		System.out.println("Porcentagem de usuarios que preferem compartilhamento de carros: ");
		System.out.println(quantidadeCarrosBicicletas[0] + "%");
		System.out.println();
		System.out.println("Porcentagem de usuarios que preferem o compartilhamento de bicicletas: ");
		System.out.println(quantidadeCarrosBicicletas[1] + "%");
		System.out.println();
	}
}
