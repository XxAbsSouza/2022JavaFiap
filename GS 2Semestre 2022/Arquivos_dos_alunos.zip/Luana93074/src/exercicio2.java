import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		double bicicletas = 0,  carros = 0, total;
		int usuarios;
		
		System.out.print("Digite a quantidade de usuarios pesquisados --> ");
		usuarios = sc.nextInt();
		
		for(int i = 0; i < usuarios; i++) {
			int aux = 0; 
			System.out.println("Usuario" + (i + 1) + "#");
			System.out.println("Digite a preferencia de implementação");
			System.out.println("Digite 1 para BICICLETAS | Digite 2 para CARROS");
			aux = sc.nextInt();
			
			if(aux == 1 || aux == 2) {
				if(aux == 1)
				bicicletas++;
						
			 else {
				carros++;
				}
			}
			else {
				i--;
				System.out.println("Opção inválida");
			}
		}
		total = carros + bicicletas;
		carros = (carros/total) * 100;
		bicicletas = (bicicletas / total) * 100;
		
		
		System.out.println("Carros" + " " +  carros + "%");
		System.out.println("Bicicletas" + " " + bicicletas + "%");
		
		
	}

}
