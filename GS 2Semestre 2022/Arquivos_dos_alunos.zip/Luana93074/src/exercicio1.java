import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int usuarios = 0, minutos;
		String[] nomes = null;
		double[][] Carros = null;
		double total = 0;
		
		usuarios = quantidadeUsuarios(usuarios);
		nomes = pegarNome(nomes, usuarios);
		imprimirNome(nomes);
		Carros = Info(Carros, usuarios, nomes);
		
		

	}
	public static int quantidadeUsuarios(int usuarios) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Digite a quantidade de usuarios --> ");
		usuarios = sc.nextInt();
		return usuarios;
		
	}
	
	public static double[][] Info(double[][] Carros, int usuarios, String[] nome) {
		Scanner sc = new Scanner(System.in);
		 Carros = new double[usuarios][3];
		
		for(int i = 0; i < usuarios; i++) {
			System.out.print("Usuario" + " " + nome[i] + ":");
			System.out.println();
			do {
				System.out.println("Qual categoria deseja? 1, 2 ou 3? ");
				Carros[i][0] = sc.nextDouble();
			} while (Carros[i][0] < 1.0 || Carros[i][0] > 3);
			System.out.println("Quantos minutos utilizou? ");
			
				
				Carros[i][1] = sc.nextDouble();
				if(Carros[i][0] == 1) {
					Carros[i][2] = Carros[i][1]*0.5;
				} else if(Carros[i][0] == 2) {
					Carros[i][2] = Carros[i][1]*0.75;
				} else {
					Carros[i][2] = Carros[i][1]*1.25;
				}
				
			}
		return Carros;
		
	}
	
	public static String[] pegarNome(String [] nome, int usuarios) {
		Scanner sc = new Scanner(System.in);
		nome = new String[usuarios];
		for(int i = 0; i < usuarios; i++) {
			System.out.print("Nome do" + " " + (i + 1) + " " + "Usuario: ");
			nome[i] = sc.nextLine();
			
		}
		return nome;
	}
	
	
	
	public static void imprimirNome(String[] nome) {
		System.out.println();
		for(int i = 0; i < nome.length; i++) {
			System.out.println(nome[i]);
			System.out.println();
		}
	}
	
	public static void imprimirInfo(double[][] Carros, int usuarios, String[] nome) {
		System.out.println("\n");
		for(int i = 0; i < Carros.length; i++) {
			System.out.println();
		}
		
	}
	
	
	
	
	
	}


