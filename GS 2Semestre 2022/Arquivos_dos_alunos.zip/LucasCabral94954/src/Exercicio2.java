import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int qtdUsuario;
		int preferencia;
		double preferenciaCarro = 0;
		double preferenciaBicileta = 0;
		
		System.out.print("Quantidade de usuarios: ");
		qtdUsuario = teclado.nextInt();
		
		for (int i=0; i<qtdUsuario; i++) {
			System.out.println("Digite [1] se prefere a implantacao do compartilhamento de carros");
			System.out.println("Digite [2] se prefere a implantacao de alguel de biciletas");
			
			System.out.print("\nDigite aqui: ");
			preferencia = teclado.nextInt();
			
			if (preferencia == 1) {
				preferenciaCarro++;
			}else {
				preferenciaBicileta++;
			}
		}
		
		preferenciaCarro = preferenciaCarro*100/qtdUsuario;
		preferenciaBicileta = 100 - preferenciaCarro;
		
		System.out.println("Preferem carro (%): " + String.format("%.2f", preferenciaCarro));
		System.out.println("Preferem bicicleta (%): " + String.format("%.2f", preferenciaBicileta));
		

	}

}
