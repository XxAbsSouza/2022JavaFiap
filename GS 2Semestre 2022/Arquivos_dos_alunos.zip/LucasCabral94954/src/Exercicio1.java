import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);	
		int qtdUsuario;
		
		System.out.print("Quantidade de usuarios: ");
		qtdUsuario = teclado.nextInt();
		
		String []nome = new String [qtdUsuario];
		int []categoria = new int [qtdUsuario];
		int []tempo = new int [qtdUsuario];
		double []receita = new double [qtdUsuario];
		
		teclado.nextLine();
	
		preencher(nome, categoria, tempo);
		
		calculoGasto(nome, categoria, tempo, receita);
		
		System.out.println("Receita (valor total) R$ " + String.format("%.2f", valorTotal(receita)));
	}
	
	public static void preencher (String []nome, int []categoria, int []tempo) {
		Scanner teclado = new Scanner(System.in);	
		for (int i=0; i<nome.length; i++) {
			System.out.print("Nome do usuario " + (i+1) + ": ");
			nome[i]=teclado.nextLine();
			
			System.out.print("Categoria: ");
			categoria[i]=teclado.nextInt();
			teclado.nextLine();
			
			System.out.print("Tempo (em minutos): ");
			tempo[i]=teclado.nextInt();
			teclado.nextLine();
			System.out.println();			
		}
	}
	
	public static void calculoGasto (String []nome, int []categoria, int []tempo, double []receita) {
		for (int i=0; i<nome.length; i++) {;
			if (categoria[i]==1) {
				receita[i] = 0.5 * tempo[i];
			}else {
				if (categoria[i]==2) {
					receita[i]= 0.75 * tempo[i];
				}else {
					receita[i] = 1.25 * tempo[i];
				}
			}
			
			System.out.println("O usuario " + nome[i] + " gastou R$ " + String.format("%.2f", receita[i]));
		}	
		
	}
	
	public static double valorTotal (double []receita) {
		double total=0;
		for (int i=0; i<receita.length; i++) {
			total=receita[i]+total;
		}
		
		return total;
	}
	
	
	
	
	
	
	
	
	
	

}
