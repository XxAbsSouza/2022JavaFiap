import java.util.Scanner;

public class Exercicio2 {

	public static void main(String[] args) {
		int usuarios, quantidadeRespBicicleta = 0, quantidadeRespCarros = 0, respostacarros, respostabicicleta;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Digite a quantidade de usuarios pesquisados--> ");
		usuarios = sc.nextInt();
		
		System.out.println();
		
		for (int i = 0; i < usuarios; i++) {
			System.out.println("Se deseja a implementação do compartilhamento de carros digite (0), caso contrario (1)");
			respostacarros = sc.nextInt();
			System.out.println();
			System.out.println("Se deseja a implementação do aluguel de bicicletas digite (0), caso contrario (1)");
			respostabicicleta = sc.nextInt();
			
			if(respostacarros > 1 && respostabicicleta > 1) {
				System.out.println("Porfavor, digite 0 ou 1 ");
			} 
			quantidadeRespCarros = respostacarros * 100;
			quantidadeRespBicicleta = respostabicicleta *100;
			
			System.out.print("A porcentagem de usuarios que preferem o compartilhamento de carros é: " + quantidadeRespCarros);
			System.out.println();
			System.out.print("A porcentagem de usuarios que preferem o compartilhamento de bicicleta é: " + quantidadeRespBicicleta);
			
			
			
		}	
		
	}

}
