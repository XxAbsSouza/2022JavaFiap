import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		int quantidadeUsuario;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Digite o numero de ususarios que utilizaram o sistema --> ");
		quantidadeUsuario = sc.nextInt();
		
		System.out.println();
		
		int[] categoriaCarro = new int [quantidadeUsuario];
		int[] TempodoUsuario = new int [quantidadeUsuario];
		String []Nomes = new String[quantidadeUsuario];
		
		completar(categoriaCarro, TempodoUsuario, Nomes);
		Calcular(categoriaCarro, TempodoUsuario, Nomes);
		
	}
	
	public static void completar(int []TempodoUsuario, int[]categoriaCarro, String[]Nomes) {
		Scanner sc = new Scanner(System.in);
		for(int i = 0; i<Nomes.length; i++) {
			
			System.out.print("Qual o nome do Usuario " + (i + 1 ) + "? ");
			Nomes[i] = sc.nextLine();	
			System.out.println();
			
			System.out.print("Categoria do veiculo : ");
			categoriaCarro[i] = sc.nextInt();
			sc.nextLine();
			System.out.println();
			
			System.out.print("Tempo gasto pelo usuario: ");
			TempodoUsuario[i] = sc.nextInt();
			sc.nextLine();
			System.out.println();
		}
	}
	
	public static void Calcular(int []TempodoUsuario, int[]categoriaCarro, String[]Nomes) {
		for(int i = 0; i<Nomes.length; i++) {
			double gastos = 0;
			
			if(categoriaCarro[i] == 2) {
				gastos = 0.75 * TempodoUsuario[i];
			} else {
				if (categoriaCarro[i] == 1) {
					gastos = 0.50 * TempodoUsuario[i];
				} else {
					gastos = 1.25 * TempodoUsuario[i];
				}
			}
			
			System.out.println();
			
			System.out.println("Os gastoso do Usuario " + (i + 1) + " " + "sao: " + gastos + " Reais!");	
		}
		
	}

}
