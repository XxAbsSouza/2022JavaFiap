import java.util.Scanner;

public class exercicio_2 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int quantUsuario = 0;
		String[] nome = new String[quantUsuario];
		int[] tempo = new int[quantUsuario];
		int[] categoria = new int[quantUsuario];
		
		System.out.print("Quantidade de Usuarios: ");
		quantUsuario = teclado.nextInt();
		
		armazenar(quantUsuario, nome, tempo, categoria);
		listagem(quantUsuario, nome, tempo, categoria);
		
	}
	public static void armazenar(int quantUsuario, String[] nome, int[] tempo, int[] categoria) {
		Scanner teclado = new Scanner(System.in);
		String[] nomeNovo = new String[quantUsuario];
		int[] tempoNovo = new int[quantUsuario];
		int[] categoriaNovo = new int[quantUsuario];
		
		for(int i = 0; i < quantUsuario; i++) {
			System.out.println();
			System.out.print("Nome do usuario " + (i + 1) + ": ");
			nomeNovo[ i ] = teclado.nextLine();
			System.out.print("Categoria 1, 2 ou 3: ");
			categoriaNovo[ i ] = teclado.nextInt();
			System.out.print("Tempo, em minutos: ");
			tempoNovo[ i ] = teclado.nextInt();
			teclado.nextLine();
		}
	}
	
	public static void listagem(int quantUsuario, String[] nome, int[] tempo, int[] categoria) {
		double[] aluguel = new double[quantUsuario];
		int[] tempoNovo2 = new int[quantUsuario];
		int[] categoriaNovo2 = new int[quantUsuario];
		for(int i = 0; i < quantUsuario; i++) {
			if(categoriaNovo2[ i ] == 1) {
				aluguel[ i ] = 0.5 * tempoNovo2[ i ];
				System.out.println(aluguel[ i ]);
			} else if(categoria[ i ] == 2) {
				aluguel[ i ] = 0.75 * tempoNovo2[ i ]; 
				System.out.println(aluguel[ i ]);
			} else {
				aluguel[ i ] = 1.25 * tempoNovo2[ i ];
				System.out.println(aluguel[ i ]);
			}
		}
	}
}
