import java.util.Scanner;

public class exercicio_1 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int usuario = 0;
		int aux = 0;
		double porcentagemCarro, porcentagemBicicleta;
		
		System.out.print("Quantidade de Usuarios: ");
		usuario = teclado.nextInt();
		
		int[] preferencia = new int[usuario];
		
		for(int i = 0; i < usuario; i++) {
			System.out.println("\nUsuario " + (i + 1));
			System.out.print("Compartilhamento de carro digite 1, aluguel de bicicleta digite 2: ");
			preferencia[ i ] = teclado.nextInt();
			if(preferencia[ i ] == 1) {
				aux++;
			}
		}
		System.out.println();
		porcentagemCarro = (100 * aux) / usuario;
		System.out.println("Preferencia de carros: " + porcentagemCarro + " %");
		porcentagemBicicleta = 100 - porcentagemCarro;
		System.out.println("Preferencia de bicicletas: " + porcentagemBicicleta + " %");
	}

}
