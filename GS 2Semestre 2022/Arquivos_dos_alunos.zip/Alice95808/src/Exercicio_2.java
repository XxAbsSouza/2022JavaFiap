import java.util.Scanner;

public class Exercicio_2 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int usuarioMes;
		
		
		System.out.print("Quantidade de usuários no mês --> ");
		usuarioMes = teclado.nextInt();
		
		String [] usuario = new String [usuarioMes];
		int [] categoriaCarro = new int [usuarioMes];		
		int [] minutos = new int [usuarioMes];
		double [] receita = new double[usuarioMes];
		
		
		dadosUsuarios(usuario,categoriaCarro,minutos);
		
		for( int i=0; i<receita.length;i++) {
			if(categoriaCarro[i]==1) {
				
				receita[i] = 0.50 * minutos[i];
				
			}else if(categoriaCarro[i]==2) {
				receita[i] = 0.75 * minutos[i];
				
			}else {
				receita[i] = 1.25 * minutos[i];				
			}
		}
		
		imprimirGasto(usuario,receita);
		imprimirReceita(receita);
		
		teclado.close();

	}
	
	public static void dadosUsuarios(String[] usuario, int[] categoriaCarro, int[] minutos) {
		
		Scanner teclado = new Scanner(System.in);
		
		for(int i=0; i<usuario.length;i++) {
			
			System.out.print("Usuario#" + (i+1) + ": ");
			usuario[i] = teclado.nextLine();
			
			System.out.print("Categoria do carro (1,2 ou 3): ");
			categoriaCarro [i] = teclado.nextInt();
			
			System.out.print("Tempo de uso em minutos: ");
			minutos [i] = teclado.nextInt();
			
			teclado.nextLine();
		}
		teclado.close();
		
	}
	
	public static void imprimirGasto (String[] usuario, double [] receita) {
		
		for(int i=0;i<usuario.length;i++) {
			System.out.println(usuario[i] + " gastou R$ "+ String.format("%.2f", receita [i]));
		}
		
		
		
	}
	public static void imprimirReceita (double []receita) {
		
		double total = 0;
		for(int i=0;i<receita.length;i++) {
			total += receita[i];
		}
		System.out.println("Receita Total R$ "+ String.format("%.2f", total));
	}
}
