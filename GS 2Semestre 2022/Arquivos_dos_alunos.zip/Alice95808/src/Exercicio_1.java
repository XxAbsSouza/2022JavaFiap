import java.util.Scanner;

public class Exercicio_1 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int totalPesquisados;
		
		System.out.println("Digite a quantidade usuários da apesquisa --> ");
		totalPesquisados = teclado.nextInt();
		
		String nomeUsuario;
		int [] modoTransporte = new int [totalPesquisados];
		double aux = 0;
		
		teclado.nextLine();
		
		for(int i=0; i<modoTransporte.length;i++) {
			System.out.print("Usuário #" + (i+1) + ": "  );
			nomeUsuario = teclado.nextLine();
			
			System.out.println("Escolha o modo de transporte: (1) Compartilhamento de Carros ou (2) Aluguel de Bicicleta");
			modoTransporte [i] = teclado.nextInt();
			
			teclado.nextLine();
			
		}
		
		for(int i=0; i<modoTransporte.length; i++) {
			if(modoTransporte[i] == 1) {
				aux += 1;
			}
		}
		System.out.println("Compartilhamento de carro: " + String.format("%.2f",(aux/totalPesquisados)*100) + "%");
		System.out.println("Aluguel de Bicicleta: " + String.format("%.2f",(1 - aux/totalPesquisados)*100) + "%");
		
		teclado.close();
		
		

	}

}
