import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int categoria;
		int tempo;
		int nome;
		
		categoriaCarro(categoria,tempo,nome);
		
		
		System.out.println("Insira a quantidade de compartilhamento de carros no último mês");
		int nCompartilhamento = teclado.nextInt();
		
		
		
		
		
	}
	
	
	
	public static int categoriaCarro(int categoria, int tempo,int nome){
		int[] pessoa = new int [3];
		Scanner teclado= new Scanner(System.in);
		System.out.println("insira o nome do cliente -->");
		String nomep = new String();
		pessoa[0] = nome;
		
		
		
		System.out.println("Categoria do carro");
		categoria = teclado.nextInt();
		pessoa[1] = categoria;
		
		System.out.println("tempo de uso do carro");
		tempo = teclado.nextInt();
		pessoa[2] = tempo;
		
		return pessoa;
	}

}
