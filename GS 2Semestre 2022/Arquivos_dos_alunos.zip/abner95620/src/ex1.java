import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		// nota = new [qtdAluno];
		// String.format(null, args);

		System.out.println("Insira a quantidade de usuários pesquisados");
		int nUsuarios = teclado.nextInt();

		for (int i = 0; i < nUsuarios; i++) {
			int[] nOpcao = new int[nUsuarios];

			System.out.println("para implementação do compartilhamento de carros digite--> 1");
			System.out.println("para implementação de aluguel de bicicletas digite--> 2");
			int opcao = teclado.nextInt();
			
			int totalOpcao1 = 0;
			int totalOpcao2 = 0;
			for (int j = 0; j < i; j++) {
				int opcao1 = 0;
				int opcao2 = 0;
				
				
				if (opcao == 1) {
					opcao1++;
					totalOpcao1 +=opcao1;

				} else if (opcao == 2) {
					opcao2++;
					totalOpcao2+=opcao2;
				}
				else {
					System.out.println("insira um número entre 1 e 2.");
				}
				
				
				int totalOpcaoTodos = totalOpcao1 + totalOpcao2;
				int porcentagem1 = totalOpcaoTodos - totalOpcao2 *100;
				int porcentagem2 = totalOpcaoTodos - totalOpcao1 *100;
				
				System.out.println("A porcentagem da opção 1 é :" + porcentagem1);
				System.out.println("A porcentagem da opção 2 é :" + porcentagem2);
				
				
				
				
			}
			

		}

	}

}
