import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int numeroUsuario;
		
		System.out.print("Digite a quantidade de usuários que utilizaram o sistema: ");
		numeroUsuario = teclado.nextInt();
		System.out.println();
		
		String[] nome = usarNomeUsuario(numeroUsuario);
		int[] modoDeImplantacao = calcularModoDeImplantacao(numeroUsuario, nome);
		int[] minutosUsados = quantidadeMinutosUsados(numeroUsuario, nome);
		double[] gastos = valoresGastos(numeroUsuario, modoDeImplantacao, minutosUsados);
	}
	
	public static String[] usarNomeUsuario(int numeroUsuario) {
		Scanner teclado = new Scanner(System.in);
		String[] nomeUsuario = new String[numeroUsuario];
		
		for(int i = 0; i < numeroUsuario; i++) {
			System.out.print("Digite o nome do usuario: ");
			nomeUsuario[i] = teclado.next();
			System.out.println();
		}
		return nomeUsuario;
	}
	
	public static int[] calcularModoDeImplantacao(int numeroUsuario, String[] nomeUsuario) {
		Scanner teclado = new Scanner(System.in);
		int[] modoDeImplantacao = new int[numeroUsuario];
		
		for(int i = 0; i < numeroUsuario; i++) {
			System.out.println("Os carros são divididos entre categorias, dentre elas 1, 2 e 3");
			System.out.println("Informe a categoria do carro usado: ");

			modoDeImplantacao[i] = teclado.nextInt();
			System.out.println();
		}
		return modoDeImplantacao;
	}
	
	public static int[] quantidadeMinutosUsados(int numeroUsuario, String[] nomeUsuario) {
		Scanner teclado = new Scanner(System.in);
		int[] minutosUsados = new int [numeroUsuario];
		
		for(int i = 0; i < numeroUsuario; i++) {
			System.out.println("Informe quanto tempo em minutos o carro foi utilizado: ");
			minutosUsados[i] = teclado.nextInt();
		}
		return minutosUsados;
	}

	public static double[] valoresGastos(int numeroUsuario, int[] modoDeImplantacao, int[]minutosUsados) {
		double[] gastos = new double[numeroUsuario];
		
		for(int i = 0; i <numeroUsuario; i++) {
			if(modoDeImplantacao[i] == 1) {
				gastos[i] = 0.50 * minutosUsados[i];
			} else if (modoDeImplantacao[i] == 2) {
				gastos[i] = 0.75 * minutosUsados[i];
			} else {
				gastos[i] = 1.25 * minutosUsados[i];
			}
		}
		return gastos;
	}
	
	
	public static void imprimirListagem (int numeroUsuario, String[] nomeUsuario, double gastos) {
		
		for(int i = 0; i < numeroUsuario; i++) {
			System.out.println("" + nomeUsuario[i]);
			System.out.println("Valor gasto: " + String.format("%.2f", gastos));
		}
	}
	
	public static void calcularValorTotal(int numeroUsuario, double[] gastos) {
		double valorTotal = 0;
		
		for(int i = 0; i < numeroUsuario; i++) {
			valorTotal += gastos[i];
		}
		System.out.println("Total da empresa: " + String.format("%.2f", valorTotal));
	}
}
