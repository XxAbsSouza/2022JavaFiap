import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		int numeroUsuarios;
		
		System.out.print("Informe a quantidade de usuários pesquisados: ");
		numeroUsuarios = teclado.nextInt();
		System.out.println();
		
		int[] implantacao = preferenciaImplantacao(numeroUsuarios);
		double[] numeroCarrosBicicletas = calculoDaPorcentagem (numeroUsuarios, implantacao);
		
		numeroCarrosBicicletas[0] = numeroCarrosBicicletas[0] * 100 / numeroUsuarios;
		numeroCarrosBicicletas[1] = numeroCarrosBicicletas[1] * 100 / numeroUsuarios;
		
		imprimir(numeroCarrosBicicletas);
	}
	
	public static int[] preferenciaImplantacao(int numeroUsuarios) {
		Scanner teclado = new Scanner(System.in);
		int[] implantacao = new int[numeroUsuarios];
		
		for(int i = 0; i < numeroUsuarios; i++) {
			System.out.println("Digite 1 para compartilhamento de carros e 2 para aluguel de bicicletas");
			
			System.out.println("Informe a preferência do usuário: ");
			
			implantacao[i] = teclado.nextInt();
			System.out.println();
		}
		return implantacao;
	}
	
	public static double[] calculoDaPorcentagem(int numeroUsuarios, int[] implantacao) {
		double[] numeroCarrosBicicletas = new double [2];
		
		for(int i = 0; i < numeroUsuarios; i++) {
			if(implantacao[i] == 1) {
				numeroCarrosBicicletas[0]++;
			} else {
				numeroCarrosBicicletas[1]++;
			}
		}
		return numeroCarrosBicicletas;
	}
	
	public static void imprimir(double[] numeroCarrosBicicletas) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Porcentagem de usuarios que tem preferência pelo compartilhamento de carros: ");
		System.out.println(numeroCarrosBicicletas[0] + "%");
		System.out.println();
		System.out.println("Porcentagem de usuarios que tem preferência pelo compartilhamento de bicicletas: ");
		System.out.println(numeroCarrosBicicletas[1] + "%");
		System.out.println();
	}

}
