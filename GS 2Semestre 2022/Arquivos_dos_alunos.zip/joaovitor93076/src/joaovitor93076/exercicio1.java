package joaovitor93076;

import java.util.Scanner;

public class exercicio1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int numeroUsuarios =0;
		
		System.out.println("Digite a quantidade de usuarios a serem pesquisados: ");
		numeroUsuarios = sc.nextInt();
		
		prefere(numeroUsuarios);
	
		
		
		
		

	}
	
	public static void prefere(int x) {
		Scanner sc = new Scanner(System.in);
		int[] usuario = new int[x];
		int[] respostas = new int[x];
		double bike2 =0;
		double carro1 =0;
			
		for(int i =0; i<usuario.length; i++) {
			System.out.println("Digite (1) carro ou (2) bicicleta ( Caso seja digitado outo valor o mesmo sera descartado): ");
			respostas[i] = sc.nextInt();
			
			
		}
		
		for(int j =0; j<respostas.length; j++) {
			System.out.print(respostas[j] + " ");
			
			if(respostas[j] == 1 ) {
				carro1 = carro1 + 1;
			}
			if(respostas[j] == 2 ) {
				bike2 = bike2 +  1;
			}
		}
		
		
			
		System.out.println();
		System.out.println("valor carro = " + carro1);
		System.out.println("valor bike = " + bike2);
		
		double resultadoCarro = carro1/ 100;
		double resultadoBike = bike2/ 100;
			
		System.out.println();
		
		System.out.println("Valor percentual de usuarios que preferem carro =" + (resultadoCarro + "%"));
		System.out.println("Valor percentual de usuarios que preferem bike =" +  (resultadoBike + "%"));
			
		
		
		
		
		
	}

}
