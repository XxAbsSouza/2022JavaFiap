package joaovitor93076;

import java.util.Scanner;

public class exercicio2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int usuarios = 0;
		System.out.println("Digite  a quantidade de usuarios: ");
		usuarios = sc.nextInt();

		imprimir(usuarios);
		
		
		

	}

	public static void dados(int x) {
		Scanner sc = new Scanner(System.in);
		String[] nome = new String[x];
		int[] carro = new int[x];
		double[] tempo = new double[x];

		for (int j = 0; j < carro.length; j++) {
			
			
			System.out.println("Digite seu nome ");
			
			nome[j] = sc.nextLine();
			
			System.out.println("Digite  qual tipo de carro usou (1), (2) ou (3) (caso algum numero além destes sejam digitados o mesmo sera descartado) ");
			carro[j] = sc.nextInt();
			System.out.println("Digite  qual o tempo  de uso do carro em horas ");
			tempo[j] = sc.nextDouble();
			sc.nextLine();

		}

		double emprsaFatura =0;
		for (int i = 0; i < tempo.length; i++) {
			
			if (carro[i] == 1) {
				double precoHora = tempo[i] * 60;
				double preco = precoHora * 0.50;

				String name = nome[i];

				System.out.println(name + " gatou = " + preco);

				emprsaFatura += preco;
			}
			if (carro[i] == 2) {
				double precoHora = tempo[i] * 60;
				double preco = precoHora * 0.75;

				String name = nome[i];

				System.out.println(name + " gatou = " + preco);

				emprsaFatura += preco;
			}
			if (carro[i] == 3) {
				double precoHora = tempo[i] * 60;
				double preco = precoHora * 1.25;

				String name = nome[i];

				System.out.println(name + " gastou = " + preco);

				emprsaFatura += preco;
			}

		}
		System.out.println();
		System.out.println("Total que a empresa faturou = " + emprsaFatura);
		

	}
	
	public static void imprimir(int x) {
		dados(x);
		
	}
}
