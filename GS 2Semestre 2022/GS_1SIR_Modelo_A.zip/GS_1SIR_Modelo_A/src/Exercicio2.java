import java.util.Scanner;

public class Exercicio2 {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int qtdUsuario;
		
		System.out.print("Quantidade de usuários --> ");
		qtdUsuario = teclado.nextInt();
		
		String[] nome = new String[qtdUsuario];
		int[] categoria= new int[qtdUsuario];
		int[] tempo = new int[qtdUsuario];
		
		lerDados(nome, categoria, tempo);
		imprimirListagem(nome, categoria, tempo);
		imprimirValorTotal(categoria, tempo);

	}

	public static void imprimirValorTotal(int[] categoria, int[] tempo) {
		System.out.println("\n ------------ Total Recebido ------------");
		double total = 0;
		for(int i = 0; i < categoria.length; i++) {
			if(categoria[i] == 1) {
				total += tempo[i] * 0.50;
			} else if(categoria[i] == 2) {
				total += tempo[i] * 0.75;
			} else {
				total += tempo[i] * 1.25;
			}			
		}
		System.out.println("Total recebido --> R$ " + String.format("%.2f", total));		
	}

	public static void imprimirListagem(String[] nome, int[] categoria, int[] tempo) {
		System.out.println("\n ------------ Listagem ------------");
		double total;
		for(int i = 0; i < nome.length; i++) {
			if(categoria[i] == 1) {
				total = tempo[i] * 0.50;
			} else if(categoria[i] == 2) {
				total = tempo[i] * 0.75;
			} else {
				total = tempo[i] * 1.25;
			}
			System.out.println(nome[i] + " --> R$ " + String.format("%.2f", total));
		}
		
	}

	public static void lerDados(String[] nome, int[] categoria, int[] tempo) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("\n ------------ Entrada de Dados ------------");
		for(int i = 0; i < nome.length; i++) {
			System.out.print("Nome --> ");
			nome[i] = teclado.nextLine();
			System.out.print("Categoria (1, 2 ou 3) --> ");
			categoria[i] = teclado.nextInt();
			System.out.print("Tempo (em minutos) --> ");
			tempo[i] = teclado.nextInt();
			teclado.nextLine();
			System.out.println();
		}
		
	}

	
}
