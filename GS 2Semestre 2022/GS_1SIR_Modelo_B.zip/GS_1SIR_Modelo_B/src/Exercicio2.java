import java.util.Scanner;

public class Exercicio2 {

public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		int qtdAluno, favorCarro = 0, favorBicicleta = 0;
		double porcentagemCarro, porcentagemBicicleta;
		int resposta;
		
		// entra com a quantidade de alunos
		System.out.print("Qual a quantidade de alunos pesquisados? --> ");
		qtdAluno = teclado.nextInt();
		
		// lê a resposta de cada aluno
		for(int i = 1; i <= qtdAluno; i++) {
			System.out.print("Digite 1 para carro ou 2 para bicicleta --> ");
			resposta = teclado.nextInt();
			if(resposta == 1) {
				favorCarro++;
			} else {
				favorBicicleta++;
			}
		}
		
		// calcula as porcentagens
		porcentagemCarro = (double) favorCarro / qtdAluno * 100;
		porcentagemBicicleta = (double) favorBicicleta / qtdAluno * 100;
		
		// imprime as porcentagens com duas casas decimais
		System.out.println("Favor de carro --> " + String.format("%.2f%%", porcentagemCarro));
		System.out.println("Favor de bicicleta --> " + String.format("%.2f%%", porcentagemBicicleta));

	}

}
